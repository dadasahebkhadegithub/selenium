package reportHandler;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.IClassListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.model.Media;
import com.aventstack.extentreports.model.MediaType;
import com.aventstack.extentreports.model.ScreenCapture;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import baseTest.BaseTest;
import baseTest.BaseTestPractice;

public class ReportListenerTest extends  BaseTestPractice
        implements ITestListener, IClassListener, ISuiteListener {

    public static ExtentReports extent;
 // public  static ExtentTest test;
    private static ExtentHtmlReporter htmlReporter;
    private static Media med;
    private static MediaEntityModelProvider mp;
    private static RemoteWebDriver webDriver;
    String screen, screen1 = null;
    int dpFileName=1;

    // Save extent reports path
    private static String filePathEx = System.getProperty("user.dir") +"//extent_reports/" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis())) + "extentreport.html";;
    // Save screenshot path
    String filePath = System.getProperty("user.dir")+"//screenshots/";
    int count = 1, count1 = 1;
    String line = "<td class=\"result\">";
    String method[] = new String[100];
    String method1[] = new String[100];
    ITestResult result;

    public void onStart(ISuite suite) {
        extent = getExtent();
        System.out.println("Suite start");
    }

    public void onStart(ITestContext context) {
        System.out.println("Test will be started");
    }

    public void onBeforeClass(ITestClass testClass) {
    	System.out.println("Report Listner");
       test = extent.createTest(testClass.getRealClass().getSimpleName());
       System.out.println("DK_onBeforeClass"+testClass.getRealClass().getSimpleName());
    }

    public void onTestStart(ITestResult result) {
        webDriver = BaseTestPractice.getContext().getSelenium().getWebDriver();
        System.out.println(" Test case is started");
    }

    public void onTestSuccess(ITestResult result) {
    	method[count - 1] = result.getName().toString().trim();
        this.result = result;
        takeScreenShot(method[count - 1], BaseTestPractice.getContext().getSelenium().getWebDriver());
        med = new ScreenCapture();// not understood
        med.setMediaType(MediaType.IMG);//not understood
        med.setPath(screen1);//not understood
        mp = new MediaEntityModelProvider(med);
        System.out.println("DK_onTestSuccess"+result.getMethod().getMethodName() + " " +result.getMethod().getDescription());
          //test.createNode(result.getMethod().getMethodName(), result.getMethod().getDescription())
          
          childTest.pass(MarkupHelper.createLabel("PASS", ExtentColor.GREEN))
        	.pass("Screenshot " + result.getMethod().getMethodName(), mp)
             .log(Status.PASS, result.getTestName());
          count++;
        System.out.println("Test case is executed successfully");
    }

    public void onTestSkipped(ITestResult result) {
        System.out.println("***** Skip " + result.getName() + " test has failed *****");
        method1[count1 - 1] = result.getName().toString().trim();
        this.result = result;
        takeScreenShot(method1[count1 - 1], BaseTestPractice.getContext().getSelenium().getWebDriver());
        med = new ScreenCapture();//Not Understood 
        med.setMediaType(MediaType.IMG);//	
        med.setPath(screen1);//
        mp = new MediaEntityModelProvider(med);//
        //test.createNode(result.getMethod().getMethodName(), result.getMethod().getDescription())
        
        childTest.skip(MarkupHelper.createLabel("SKIP", ExtentColor.BLUE))
                .skip("Screenshot " + result.getMethod().getMethodName(), mp)
                .log(Status.SKIP, result.getThrowable());
        count++;
        System.out.println("Test case is skipped");
    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
    }

    public void onTestFailure(ITestResult result) {
        System.out.println("***** Error " + result.getName() + " test has failed *****");
        method[count - 1] = result.getName().toString().trim();
        this.result = result;
        takeScreenShot(method[count - 1], BaseTestPractice.getContext().getSelenium().getWebDriver());
        med = new ScreenCapture();// not understood
        med.setMediaType(MediaType.IMG);//not understood
        med.setPath(screen1);//not understood
        mp = new MediaEntityModelProvider(med);//not understood
        //test.createNode(result.getMethod().getMethodName(), result.getMethod().getDescription())
        childTest.fail(MarkupHelper.createLabel("FAIL", ExtentColor.RED))
                .fail("Screenshot " + result.getMethod().getMethodName(), mp)
                .log(Status.FAIL, result.getThrowable());
        count++;
        System.out.println("Test case is failed");
    }

    public void onAfterClass(ITestClass testClass) {
        System.out.println("Class ending" + testClass.getRealClass().getSimpleName());
    }

    public void onFinish(ITestContext context) {
        System.out.println("Test will be ending");
    }

    public void onFinish(ISuite suite) {
        extent.flush();
        System.out.println("Suite Finish");
        
    }

    public void takeScreenShot(String methodName, RemoteWebDriver driver) {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            File scrFile2 = new File(filePath + methodName + ".png");
            System.setProperty("org.uncommons.reportng.escape-output", "false");
           
            if (scrFile2.exists()){
            	String str=methodName+dpFileName;
            	
            File scrFileNew= new File(filePath+str+".png");
            FileUtils.copyFile(scrFile, scrFileNew);
            screen1 = scrFileNew.toString();
            screen = "<img src='" + scrFileNew.toString() + "' width='200' height='200'  > ";//not
            Reporter.setEscapeHtml(false);//not understood
            Reporter.log(screen);
            dpFileName++;
            
            }
            
           else {
            FileUtils.copyFile(scrFile, scrFile2);
           
            System.out.println("***Placed screen shot in " + filePath + " ***");
            screen1 = scrFile2.toString();
            screen = "<img src='" + scrFile2.toString() + "' width='200' height='200'  > ";//not
            Reporter.setEscapeHtml(false);//not understood
            Reporter.log(screen);
           }
        }
         catch (IOException e) {
            e.printStackTrace(); 
        }
        
        }
        
    
    


   /* public static ExtentReports getExtent() {
        if (extent == null) {
            extent = new ExtentReports();//this class has constructor but here not written in my practice example they have mentioned constructor I checked version it is different  
            
            extent.attachReporter(getHtmlReporter());
        }
        return extent;
    }

    private static ExtentHtmlReporter getHtmlReporter() {
        htmlReporter = new ExtentHtmlReporter(filePathEx);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle("SQACRM Web Automation");
        htmlReporter.config().setReportName("SQACRM  Web Automation Report");
        
        //ExtentHtmlReporterConfiguration a=  htmlReporter.config();
        //htmlReporter.
       //a.
        
        return htmlReporter;
        
    }
*/

}
