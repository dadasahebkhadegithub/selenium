/**
 * @author Rajani Sinha
 */
package dataHandlers;

import org.apache.log4j.Logger;
import selenium.Selenium;
import utils.Config;

public class GlobalData {

	private static GlobalData globalData;
	private Selenium selenium;
	private Logger log = Logger.getLogger(GlobalData.class);

	private GlobalData() throws Exception {
		
			if (Config.detectTabletMode()) {
				selenium = new Selenium();
			} else {
				selenium = new Selenium(Config.BROWSER, Config.LOCALE);
				//selenium.get();
			}
		}
	

	public static GlobalData getInstance() throws Exception {
		if (globalData == null)
			return globalData = new GlobalData();
		return globalData;
	}

	
	public Selenium getSelenium() {
		return selenium;
	}

	public void setSelenium(Selenium selenium) {
		this.selenium = selenium;
	}

}
