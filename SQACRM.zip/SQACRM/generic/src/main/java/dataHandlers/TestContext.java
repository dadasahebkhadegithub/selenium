/**
 * @author Rajani Sinha
 */
package dataHandlers;

import selenium.Selenium;

public class TestContext {

	private  Selenium selenium;

	public Selenium getSelenium() {
		return this.selenium;
	}

	public void setSelenium(Selenium selenium) {
		this.selenium = selenium;
	}
	
	
}
