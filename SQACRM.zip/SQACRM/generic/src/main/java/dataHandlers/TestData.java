/**
 * @author Rajani Sinha
 */
package dataHandlers;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestData {

	private JSONObject jsonData;

	public TestData(String testClassName) {
		try {
			String[] strs = testClassName.split("\\.");
			testClassName = strs[strs.length - 1];
			String jsonFilePath = System.getProperty("user.dir") + File.separator + "testdata" + File.separator
					+ testClassName + ".json";
			JSONParser parser = new JSONParser();
			jsonData = (JSONObject) parser.parse(new FileReader(jsonFilePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Read Data
	 * 
	 * @param methodName
	 * @param attributeName
	 * @return
	 */
	public String getData(String methodName, String attributeName) {
		if (!isDataPresent(methodName, attributeName)) {
			Assert.fail("Data not found. MethodName : " + methodName + ", AttributeName : " + attributeName);
		}
		return (String) ((JSONObject) jsonData.get(methodName)).get(attributeName);
	}
	public JSONObject getObject(String methodName, String attributeName) {
		if (!isDataPresent(methodName, attributeName)) {
			Assert.fail("Data not found. MethodName : " + methodName + ", AttributeName : " + attributeName);
		}
		return (JSONObject) ((JSONObject) jsonData.get(methodName)).get(attributeName);
	}

	/**
	 * Get Data Array
	 * 
	 * @author rsinha
	 * @param methodName
	 * @param attributeName
	 * @return
	 */
	public List<String> getDataArray(String methodName, String attributeName) {
		if (!isDataPresent(methodName, attributeName)) {
			Assert.fail("Data not found. MethodName : " + methodName + ", AttributeName : " + attributeName);
		}

		JSONArray jsonArray = (JSONArray) (((JSONObject) jsonData.get(methodName)).get(attributeName));
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < jsonArray.size(); i++) {
			list.add((String) jsonArray.get(i));
		}
		return list;
	}
	public List<String> getDataArray(JSONArray jsonArrayObj) {
		JSONArray jsonArray = jsonArrayObj;
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < jsonArray.size(); i++) {
			list.add((String) jsonArray.get(i));
		}
		return list;
	}
	public JSONArray getArrayObj(String methodName, String attributeName) {
		if (!isDataPresent(methodName, attributeName)) {
			Assert.fail("Data not found. MethodName : " + methodName + ", AttributeName : " + attributeName);
		}

		JSONArray jsonArray = (JSONArray) (((JSONObject) jsonData.get(methodName)).get(attributeName));
		
		return jsonArray;
	}

	/**
	 * Is data present
	 * 
	 * @param methodName
	 * @param attributeName
	 * @return boolean
	 */
	public boolean isDataPresent(String methodName, String attributeName) {
		return jsonData.containsKey(methodName) ? ((JSONObject) jsonData.get(methodName)).containsKey(attributeName)
				: false;

	}

}
