/**
 * @author Rajani Sinha
 */
package selenium;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.expression.ParseException;
import org.testng.Assert;

import io.appium.java_client.windows.WindowsDriver;
import utils.Config;
import utils.Locator;

public class Selenium {

    private Logger log = Logger.getLogger(Selenium.class);
    private RemoteWebDriver webDriver;
    private WindowsDriver windowsDriver;
    private String webDriverFile_ie = "IEDriverServer.exe";
    private String webDriverFile_edge = "MicrosoftWebDriver.exe";
    private String webDriverFile_win_chrome = "chromedriver.exe";
    private String webDriverFile_mac_chrome = "chromedriver";

    private long timeOutInSeconds = 120L;

    public Selenium() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("app", Config.APP_PATH);
        try {
            windowsDriver = new WindowsDriver(new URL(Config.URL), capabilities);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Create a WebDriver Instance
     *
     * @param browser
     * @param locale
     * @throws Exception
     */
    public Selenium(String browser, String locale) throws Exception {

        String driverRelativePath = "generic" + File.separator + "drivers" + File.separator;
        String osType = getOperatingSystemType();

        switch (browser.toLowerCase()) {
            case "ie":
                log.info("Initializing driver for Internet Explorer...");
                if (osType.equals("Windows")) {
                    System.setProperty("webdriver.ie.driver", driverRelativePath + webDriverFile_ie);
                    InternetExplorerOptions options = new InternetExplorerOptions();
                    options.introduceFlakinessByIgnoringSecurityDomains();
                    webDriver = new InternetExplorerDriver(options);
                    log.info("Driver for Internet Explorer initialized.");
                    break;
                } else {
                    throw new Exception("You are not running the tests on windows operating system");
                }
            case "edge":
                log.info("Initializing driver for Edge...");
                if (osType.equals("Windows")) {
                    System.setProperty("webdriver.edge.driver", driverRelativePath + webDriverFile_edge);
                    EdgeOptions options = new EdgeOptions(); //we can add the options for edge in future as we need
                    webDriver = new EdgeDriver(options);
                    webDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                    log.info("Driver for Edge initialized.");
                    break;
                } else {
                    throw new Exception("You are not running the tests on windows operating system");
                }
            case "chrome":
                log.info("Initializing driver for Chrome...");
                List<String> arguments = new ArrayList<String>();
                arguments.add("--lang=" + locale);
                arguments.add("--allow-file-access-from-files");
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments(arguments);

                if (osType.equals("MacOS")) {
                    System.setProperty("webdriver.chrome.driver", driverRelativePath + webDriverFile_mac_chrome);
                    webDriver = new ChromeDriver(chromeOptions);
                    log.info("Driver for Chrome initialized.");
                    break;
                } else if (osType.equals("Windows")) {
                    System.setProperty("webdriver.chrome.driver", driverRelativePath + webDriverFile_win_chrome);
                    webDriver = new ChromeDriver(chromeOptions);
                    log.info("Driver for Chrome initialized.");
                    break;
                } else if (osType.equals("Linux")) {

                } else {
                    throw new Exception("Please check your operating system");
  
                }
            case "firefox":
                log.info("Initializing driver for Firefox...");
                FirefoxProfile firefoxProfile = new FirefoxProfile();
                firefoxProfile.setPreference("intl.accept_languages", locale);
                firefoxProfile.setPreference("browser.download.dir", "C:/Users/Administrator/Downloads");
                firefoxProfile.setPreference("browser.download.folderList", 2);
                firefoxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk",
                        "text/plain application/zip application/tar");
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.setProfile(firefoxProfile);
                webDriver = new FirefoxDriver(firefoxOptions);
                log.info("Driver for Firefox initialized.");
                break;
            default:
                break;
        }
        webDriver.manage().timeouts().implicitlyWait(1L, TimeUnit.SECONDS);
        webDriver.manage().window().maximize();
    }

    /**
     * Get WebElement
     *
     * @param locator
     * @return
     */
    public WebElement getWebElement(Locator locator) {
        return webDriver.findElement(getBy(locator));
    }

    /**
     * Get Options from Drop down
     *
     * @param locator
     * @return
     * @author rsinha
     */
    public void selectByVisibleText(Locator locator, String value) {
        Select select = new Select(getWebElement(locator));
        select.selectByVisibleText(value);
    }

    /**
     * detect the OS on which tests are running
     */
    public String getOperatingSystemType() {
        String OS = System.getProperty("os.name", "generic").toLowerCase();
        String identifiededOS;

        if ((OS.indexOf("mac") >= 0)) {
            identifiededOS = "MacOS";
        } else if (OS.indexOf("win") >= 0) {
            identifiededOS = "Windows";
        } else if (OS.indexOf("nux") >= 0) {
            identifiededOS = "Linux";
        } else {
            identifiededOS = "Other";
        }

        return identifiededOS;
    }

    /**
     * Get to default Product URL
     *
     * @throws IOException
     * @throws InterruptedException
     */
    public void get() throws IOException, InterruptedException {
//		String path = "src" + File.separator + "main" + File.separator + "resources" + File.separator;
//		Runtime.getRuntime().exec(path + "HandleAuthenticationWinodw.exe");
        get(Config.PRODUCT_URL);
    }

    /**
     * Get to URL
     *
     * @param url
     */
    public void get(String url) {
        webDriver.get(url);
    }


    /**
     * Get WebElement
     *
     * @param elem
     * @return
     */
    public WebElement getWebElement(By elem) {
        return webDriver.findElement(elem);
    }

    /**
     * Get WebElements
     *
     * @param locator
     * @return
     */
       
    
    
    
    public List<WebElement> getWebElements(Locator locator) {
        if (webDriver.findElements(getBy(locator)).size() < 0) {
            getWebElements(locator);
        }
        return webDriver.findElements(getBy(locator));
    }


    /**
     * Get By element
     *
     * @param locator
     * @return
     */
    public By getBy(Locator locator) {

        switch (locator.getType().name()) {
            case "ID":
                return By.id(locator.getValue());
            case "NAME":
                return By.name(locator.getValue());
            case "CSSSELECTOR":
                return By.cssSelector(locator.getValue());
            case "CLASSNAME":
                return By.className(locator.getValue());
            case "XPATH":
                return By.xpath(locator.getValue());
            case "LINKTEXT":
                return By.linkText(locator.getValue());
            case "PARTIALLINKTEXT":
                return By.partialLinkText(locator.getValue());
            case "TAGNAME":
                return By.tagName(locator.getValue());
            default:
                log.error("Incorrect Locator type.");
                Assert.fail("Incorrect Locator type. \nSupported - ");
                       // + Stream.of(Type.values()).map(Type::name).collect(Collectors.joining(","))
                       // + "\nIncorrect Locator - " + locator.getType());
                break;
        }
        return null;
    }

    /**
     * Send Keys
     *
     * @param locator
     * @param keys
     */
    public void sendKeys(Locator locator, String keys) {
        try {
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);
            getWebElement(locator).clear();
            getWebElement(locator).sendKeys(keys);
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).sendKeys(keys);
        }
    }

    public void sendKey(Locator locator, String keys) {
       
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);

            getWebElement(locator).sendKeys(keys);
       
        
        
        /*try {
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);

            getWebElement(locator).sendKeys(keys);
        } catch (StaleElementReferenceException e) {
           getWebElement(locator).sendKeys(keys);
        }*/
    }

    /**
     * Send Keys
     *
     * @param locator
     * @param keys
     */
    public void sendKeysWithJS(Locator locator, String keys) {
        try {
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);
            WebElement ele = getWebElement(locator);
            JavascriptExecutor jse = (JavascriptExecutor) webDriver;
            jse.executeScript("arguments[0].value='" + keys + "';", ele);
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).sendKeys(keys);
        }
    }

    /**
     * Click on WebElement
     *
     * @param locator
     */
    public void click(Locator locator) {
        try {
            waitForElementToBeClickable(locator);
            log.info("Clicking on element " + locator);
            getWebElement(locator).click();
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).click();
        }
        log.info("Clicked on element " + locator);
    }

    public void clickUsingJavascript(Locator locator) {
        try {
            waitForElementToBeClickable(locator);
            log.info("Clicking on element " + locator);
            WebElement ele = getWebElement(locator);
            JavascriptExecutor executor = (JavascriptExecutor) webDriver;
            executor.executeScript("arguments[0].click();", ele);
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).click();
        }
        log.info("Clicked on element " + locator);
    }

    public boolean waitForElementToBeDisplayed(Locator locator) {
        waitForElementToBeDisplayed(locator, timeOutInSeconds);
        return true;
    }

    public void clickWithJS(Locator locator) {
        System.out.println("document." + locator + ".click()");
        ((JavascriptExecutor) webDriver).executeScript("arguments[0].click()", getWebElement(locator));

    }

    /**
     * Mouse hover on Web Element
     * @param locator
     */
    public void mouseHover(Locator locator) {
        waitForElementToBeDisplayed(locator);
        Actions actions = new Actions(webDriver);
        actions.moveToElement(getWebElement(locator));
        actions.perform();
        log.info("Hovering on element " + locator);
    }

    /**
     * Mouse hover on Web Element
     * @param locator
     * @param keys
     */
    public void inputFile(Locator locator, String keys) {
        try {
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);
            getWebElement(locator).sendKeys(keys);
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).sendKeys(keys);
        }
    }

    /**
     * Get text of Web Element
     *
     * @param locator
     * @return
     */
    public String getText(Locator locator) {
        log.info("Getting text value of element " + locator);
        String text = getWebElement(locator).getText();
        log.info("Text value is - " + text);
        return text;
    }

    public void mouseHoverClick(Locator locator) {
        waitForElementToBeDisplayed(locator);
        Actions actions = new Actions(webDriver);
        actions.moveToElement(getWebElement(locator));
        actions.click().perform();
        log.info("Hovering on element " + locator);
    }

    public void JSClick(WebElement element) {
        JavascriptExecutor executor = (JavascriptExecutor) webDriver;
        executor.executeScript("arguments[0].click();", element);
    }

    public void JSClick(Locator locator) {
        JavascriptExecutor executor = (JavascriptExecutor) webDriver;
        executor.executeScript("arguments[0].click();", getWebElement(locator));
    }

    /**
     * Get Attribute value of Web Element
     *
     * @param locator
     * @param attribute
     * @return
     */
    public String getAttribute(Locator locator, String attribute) {
        log.info("Getting " + attribute + " value of element " + locator);
        String value = getWebElement(locator).getAttribute(attribute);
        log.info(attribute + " attribute value is " + value);
        return value;
    }


    /**
     * Is Web Element Present/Displayed
     *
     * @param locator
     * @return boolean
     */
    public boolean isElementPresent(Locator locator) {
        try {
            getWebElement(locator) ;
        } catch (NoSuchElementException e) {
            return false;
        }
    	//return getWebElement(locator).isEnabled();
        return true;
    }

    public boolean isElementDisplayed(Locator locator) {
        try {
            getWebElement(locator).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
        return true;
    }


    public String previousDate() {
        String previousDate = "";
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -1);
            java.util.Date before = cal.getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("dd");
            previousDate = formatter.format(before);
        } catch (NoSuchElementException e) {
            return previousDate;
        }
        return previousDate;
    }

    public String todaysDate() {
        String todaysDate = "";
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, 0);
            java.util.Date before = cal.getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("dd");
            todaysDate = formatter.format(before);
        } catch (NoSuchElementException e) {
            return todaysDate;
        }
        return todaysDate;
    }

    public String nextDate() {
        String todaysDate = "";
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, +1);
            java.util.Date before = cal.getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("dd");
            todaysDate = formatter.format(before);
        } catch (NoSuchElementException e) {
            return todaysDate;
        }
        return todaysDate;
    }

    /**
     * Navigate Back
     */
    public void navigateBack() {
        log.info("Navigating back...");
        webDriver.navigate().back();
       
        log.info("Navigated back to last page - " + webDriver.getCurrentUrl());
    }

    /**
     * Navigate Forward
     */
    public void navigateForward() {
        log.info("Navigating forward...");
        webDriver.navigate().forward();
        log.info("Navigated forward to next page - " + webDriver.getCurrentUrl());
    }

    /**
     * Wait For Element To Be Displayed
     *
     * @param locator
     * @param timeOutInSeconds
     */
    public void waitForElementToBeDisplayed(Locator locator, long timeOutInSeconds) {
        log.info("Waiting for element to be displayed - " + locator);
        (new WebDriverWait(webDriver, timeOutInSeconds)).until(ExpectedConditions.presenceOfElementLocated(getBy(locator)));
    }


    public void waitForPageLoad() {
        new WebDriverWait(webDriver, timeOutInSeconds).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    /**
     * Wait For Element Invisibility
     *
     * @param locator
     */

    public void waitForElementToBeInvisible(Locator locator) {
        log.info("Waiting for element to be invisible - " + locator);
        (new WebDriverWait(webDriver, timeOutInSeconds))
                .until(ExpectedConditions.invisibilityOfElementLocated(getBy(locator)));
    }

    public void clearField(Locator locator) {
        try {
            waitForElementToBeDisplayed(locator);
            log.info("Sending keys to " + locator);
            getWebElement(locator).clear();
        } catch (StaleElementReferenceException e) {
            getWebElement(locator).clear();
        }
    }

   
   

    /**
     * @param len length of string
     * @return random string according to the len size
     */
    public String randomStringGenrator(int len) {
        final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        SecureRandom rnd = new SecureRandom();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++)
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        return sb.toString();


    }

    /**
     * Wait for Element To Be Clickable
     *
     * @param locator
     * @param timeOutInSeconds
     */
    public void waitForElementToBeClickable(Locator locator, long timeOutInSeconds) {
        log.info("Waiting for element to be clickable - " + locator);
        (new WebDriverWait(webDriver, timeOutInSeconds)).until(ExpectedConditions.elementToBeClickable(getBy(locator)));
    }

    /**
     * Wait for Element To Be Clickable
     *
     * @param locator
     */
    public void waitForElementToBeClickable(Locator locator) {
        waitForElementToBeClickable(locator, timeOutInSeconds);
    }

    /**
     * Wait For Page Element to load
     */
    public void waitForPageElementToLoad() {
        new WebDriverWait(webDriver, timeOutInSeconds).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    /**
     * Wait For Element Invisibility
     *
     * @param locator
     */
    public void waitForElementToBeVisible(Locator locator) {
        log.info("Waiting for element to be invisible - " + locator);
        (new WebDriverWait(webDriver, timeOutInSeconds))
                .until(ExpectedConditions.visibilityOfElementLocated(getBy(locator)));
    }

    /**
     * Scroll down to the page
     */
    public void scrollDownToTheEndOfPage() {
        log.info("Scrolling down to the page - ");
        ((JavascriptExecutor) webDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    /**
     * Scroll up to the top of page
     */
    public void scrollUpToTheTopOfPage() {
        log.info("Scrolling down to the page - ");
        ((JavascriptExecutor) webDriver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
    }

    /**
     * Scroll down to the page
     */
    public void scrollDown() {
        log.info("Scrolling down to the page - ");
        ((JavascriptExecutor) webDriver).executeScript("window.scrollTo(0, 1000)");
    }

    public void scrollToElement(Locator locator) {
        log.info("Scrolling down to the page - ");
        ((JavascriptExecutor) webDriver).executeScript("arguments[0].scrollIntoView(true);", getWebElement(locator));
    }

    /**
     * Close browser
     */
    public void close() {
        log.info("Closing Browser...");
        
        webDriver.close();
        log.info("Browser Closed.");
    }

    /**
     * Quit WebDriver
     */
    public void quit() {
        log.info("Quiting WebDriver...");
        webDriver.quit();
        log.info("WebDriver quit.");
    }

    /**
     * Find Element By Accessibility Id
     *
     * @param id
     * @return
     */
    public WebElement findElementByAccessibilityId(String id) {
        return windowsDriver.findElementByAccessibilityId(id);
       
    }

    /**
     * Click on WebElement
     *
     * @param id
     */
    public void click(String id) {
        try {
            waitUntilElementToBeClickable(id);
            log.info("Clicking on element " + id);
            findElementByAccessibilityId(id).click();
        } catch (StaleElementReferenceException e) {
            findElementByAccessibilityId(id).click();
        }
        log.info("Clicked on element " + id);
    }

    /**
     * Send Keys
     *
     * @param id
     * @param value
     */
    public void sendKeys(String id, String value) {
        try {
            waitUntilVisibilityOfElementLocated(id);
            log.info("Sending keys to " + id);
            findElementByAccessibilityId(id).sendKeys(value);
        } catch (StaleElementReferenceException e) {
            findElementByAccessibilityId(id).sendKeys(value);
        }
    }

    /**
     * Wait Until Alert Is Present
     */
    public void waitUntilAlertIsPresent() {
        (new WebDriverWait(windowsDriver, timeOutInSeconds)).until(ExpectedConditions.alertIsPresent());

    }

    /**
     * Wait Until Element To Be Selected
     *
     * @param id
     */
    public void waitUntilElementToBeSelected(String id) {
        WebElement element = findElementByAccessibilityId(id);
        (new WebDriverWait(windowsDriver, timeOutInSeconds)).until(ExpectedConditions.elementToBeSelected(element));

    }

    /**
     * Wait Until Element Selection State To Be
     *
     * @param id
     * @param selected
     */
    public void waitUntilElementSelectionStateToBe(String id, boolean selected) {
        WebElement element = findElementByAccessibilityId(id);
        (new WebDriverWait(windowsDriver, timeOutInSeconds))
                .until(ExpectedConditions.elementSelectionStateToBe(element, selected));

    }

    /**
     * Wait Until Element To Be Clickable
     *
     * @param id
     */
    public void waitUntilElementToBeClickable(String id) {
        WebElement element = findElementByAccessibilityId(id);
        (new WebDriverWait(windowsDriver, timeOutInSeconds)).until(ExpectedConditions.elementToBeClickable(element));

    }

    /**
     * Wait Until Frame To Be Avaliable And Switch To It
     *
     * @param id
     */
    public void waitUntilFrameToBeAvaliableAndSwitchToIt(String id) {
        WebElement element = findElementByAccessibilityId(id);
        (new WebDriverWait(windowsDriver, timeOutInSeconds)).until(ExpectedConditions.visibilityOf(element));

    }

    /**
     * Wait Until Visibility Of Element Located
     *
     * @param id
     */
    public void waitUntilVisibilityOfElementLocated(String id) {
        WebElement element = findElementByAccessibilityId(id);
        new WebDriverWait(windowsDriver, timeOutInSeconds).until(ExpectedConditions.visibilityOf(element));

    }
    
    /**
     * SwitchToFrame for WebApplication added DK
     *
     * @param locator ,locator1,frames
     */
    public String switchToFrameToGetText(Locator locator, Locator locator1,String frames) {
    	List<WebElement> frame=   getWebElements(locator);
    		String str="";
    		for (WebElement frm :frame) {
    				//System.out.println(frm.getAttribute("name"));
        		if(frm.getAttribute("name").equals(frames)) {
        			webDriver.switchTo().frame(frm);
        			str= getText(locator1);
        			webDriver.switchTo().defaultContent();
        		}
    		}
    		return str;
    	}
    public void switchToFrame(Locator locator, Locator locator1,String frames) {
    	List<WebElement> frame=   getWebElements(locator);
    	
    		for (WebElement frm :frame) {
    				System.out.println(frm.getAttribute("name"));
        		if(frm.getAttribute("name").equals(frames)) {
        			webDriver.switchTo().frame(frm);
        			getWebElement(locator1).click();
        			webDriver.switchTo().defaultContent();
        		}
    		}
    	}
    
    public void switchToFrameToClick(Locator locator, Locator locator1,Locator locator2, String frames) {
		    	List<WebElement> frame=   getWebElements(locator);
		    	for (WebElement frm :frame) {
		    	//System.out.println(frm.getAttribute("name"));
        		if(frm.getAttribute("name").equals(frames)) {
        			webDriver.switchTo().frame(frm);
        			Actions action = new Actions(webDriver);
            		action.moveToElement(getWebElement(locator1)).build().perform();
        			getWebElement(locator2).click();
        			webDriver.switchTo().defaultContent();
        			
        		}
    		}
    	}

    
    public void switchToFrame(String frame) {
    	waitForPageLoad();
    	webDriver.switchTo().frame(frame);
    	
    }
    
    public void switchToMainPage() {
    	webDriver.switchTo().defaultContent();
    }
    
    /**
     * Close Application
     */
    public void closeApp() {
        log.info("Closing Application...");
        windowsDriver.close();
        log.info("Application Closed.");
    }

    /**
     * Quit Application
     */
    public void quitApp() {
        log.info("Quiting Application...");
        windowsDriver.quit();
        log.info("Application quit.");
    }

    public String getCurrentUrl() {
        return webDriver.getCurrentUrl();
    }

    public String getTitle() {
        return webDriver.getTitle();
    }
// DropDown value selection functions start 
    /**
     * Get Options from Drop down
     *
     * @param locator
     * @return
     * @author rsinha
     */
    public List<WebElement> getOptions(Locator locator) {
        Select select = new Select(getWebElement(locator));
        return select.getOptions();
    }

    /**
     * Get Option values from Drop down
     *
     * @param locator
     * @return
     * @author rsinha
     */
    public List<String> getOptionValues(Locator locator) {
        List<WebElement> list = getOptions(locator);
        List<String> values = new ArrayList<String>();
        log.info("Drop down values are, ");
        for (WebElement webElement : list) {
            String value = webElement.getText();
            log.info(value);
            values.add(value);
        }
        return values;
    }

    /**
     * Is Option Present Under Drop Down
     *
     * @param locator
     * @param value
     * @return
     */
    public boolean isOptionPresentUnderDropDown(Locator locator, String value) {
        List<String> values = getOptionValues(locator);
        for (String str: values) {
        	if (str.trim().equals(value)) {
        	 	Select select =new Select(getWebElement(locator));
        		select.selectByVisibleText(value);
        		return true;
        		
        		}
        	
        }
        return false;
    }
    
    /**
     * Is Option Present Under Drop Down
     *
     * @param locator
     * @param value
     * @return
     */
    public void selectValueFromDropDown(Locator locator, String value) {
        Select select = new Select(getWebElement(locator));
        select.selectByVisibleText(value);
    }

 // DropDown value selection functions end
    
    
    public void logOut() {
    	
    }
    public void pageRefresh() {
        webDriver.get(Config.PRODUCT_URL);
    }

    public boolean isEnabled(Locator locator) {
        log.info("Checking enable property of element " + locator);
        return getWebElement(locator).isEnabled();

    }

    public boolean checkIfElementIsClickable(Locator locator) {
        try {
            WebDriverWait wait = new WebDriverWait(webDriver, 6);

            wait.until(ExpectedConditions.elementToBeClickable(getWebElement(locator)));
            return true;
        } catch (Exception e) {
            return false;

        }
    }

    
    public   void selectDateFromCalendar(String date) {
    	
    	try {
    		Date current =new Date();
    		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
    		
    		Date input_date_By_User =sd.parse(date);
    		System.out.println(input_date_By_User);
    		String day=new SimpleDateFormat("dd").format(input_date_By_User);
    		if (day.startsWith("0")) {
    			day=day.substring(1);
    		}
    		String month=new SimpleDateFormat("MMMM").format(input_date_By_User);
    		String year =new SimpleDateFormat("yyyy").format(input_date_By_User);
    		String comma=",";
    		//System.out.println(month+comma+year);
    		String desiredMonthYear=month+comma+" "+year;
    		desiredMonthYear=desiredMonthYear.replaceAll("\\s","");
    		webDriver.findElement(By.xpath("//*[@id='f_trigger_c_birthday']")).click();
    		
    		
    		 System.out.println(desiredMonthYear);
    		//webDriver.findElement(By.xpath("//td[text()='"+day+"']")).click();;
    		
    		String displayedMonthYear="";
    		//displayedMonthYear=webDriver.findElement(By.xpath("//div[@class='calendar']//table/thead/tr/td[2]")).getText();
    		//displayedMonthYear=selenium.getWebElement(locator_dispalyed_monthYear).getText();
    		//System.out.println("dk"+displayedMonthYear);
    		
    		while(true) {
    			
    			
    			displayedMonthYear=webDriver.findElement(By.xpath("//div[@class='calendar']//table/thead/tr/td[2]")).getText();
    			displayedMonthYear=displayedMonthYear.replaceAll("\\s","");
    			System.out.println(displayedMonthYear);
    			System.out.println(desiredMonthYear+"----"+displayedMonthYear);
    			
    			
    			if(desiredMonthYear.equals(displayedMonthYear)) {
    				//give the xpath of the day which you want to select  
    			    webDriver.findElement(By.xpath("//td[text()='"+day+"']")).click();
    			    break;
    			 
    			}else {
    				if(input_date_By_User.compareTo(current) > 0 ) {
    					
    					webDriver.findElement(By.xpath("//div[@class='calendar']//table/thead/tr[2]/td[4]")).click();
    					
    					//give xpath of next buton of calendar icon 
    				}
    				
    				else if (input_date_By_User.compareTo(current) < 0 ) {
    					webDriver.findElement(By.xpath("//div[@class='calendar']//table/thead/tr[2]/td[2]")).click();
    					
    					//give xpath of previous button of calendar icon 
    				}
    			}
    			
    			
    			
    			
    		}
    	}
    	catch(ParseException e){
    		e.printStackTrace();
    	} catch (java.text.ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	
    	}
    	
    
   public void defaultContent() {
	   webDriver.switchTo().defaultContent();
   }
    
    public String  switchToAlertOK(String frame) {
    
    	Alert alert = webDriver.switchTo().alert();
    	String str=alert.getText().trim();
    	
    	alert.accept();
    	defaultContent();
    	switchToFrame(frame);
    	return str;
    }
    
    public void switchToAlertCancel() {
        
    	Alert alert = webDriver.switchTo().alert();
    	alert.dismiss();
    	defaultContent();
    
    }
    
    public void  switchToAlert() {
        
    	Alert alert = webDriver.switchTo().alert();
    	alert.accept();
    	defaultContent();
    	
    }

    
    public void SwitchToWindow(Locator locaotr1,Locator locaotr2,Locator locaotr3) {
    	
    	String mainWindow=webDriver.getWindowHandle();
    	Set<String>	set=webDriver.getWindowHandles();
    	
    	for (String str: set) {
    	 if(!mainWindow.equals(str)){
    		 webDriver.switchTo().window(str);
    		 sendKeys(locaotr1,"Info");
    		 getWebElement(locaotr2).click();
    		// getWebElement(locaotr3).click();
    		webDriver.close();
    		 
    	 	}
    	 
    	 
    	 }
    	 
    	 webDriver.switchTo().window(mainWindow);
    }
    
    public String parentWindow() {
    	 String mainWindow =webDriver.getWindowHandle();
    	 return mainWindow;
    }
    
    
 public String SwitchToWindow() {
    	
    	String mainWindow=webDriver.getWindowHandle();
    	Set<String>	set=webDriver.getWindowHandles();
    	String winid="";
    	for (String str: set) {
    	 if(!mainWindow.equals(str)){
    		 winid=str;
    		 		     		 
    	 	}
    	 }
    	return winid ;
    	
    }
    
 public void switchToWindowToClose(String winid) {
	   webDriver.switchTo().window(winid);
   
 }
    

 public void  currentWindowClosed() {
	 webDriver.close();
	 webDriver.switchTo().defaultContent();
	
	 
 }
    public RemoteWebDriver getWebDriver() {
        return webDriver;
    }
    
  
    
    
    
    
    
}
