/**
 * @author Rajani Sinha
 */
package utils;

import org.apache.log4j.Logger;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {

	private static Logger log = Logger.getLogger(Config.class);

	public static String PRODUCT_URL;
	public static String BROWSER;
	public static String LOCALE;
	public static boolean PARALLEL;

	public static String URL;
	public static String WINDOWS_DRIVER_PATH;
	public static String APP_PATH;
	
	/*public static String excelFilePath;
	public static String excelFileName;*/

	public static boolean detectTabletMode() {
		try{
			//RegistryKey getKey = new RegistryKey(FileUtils.readPropertyKeyValue("RegistryKey"));
			//RegistryValue value = "" //getKey.getValue("TabletMode");
			String val =  ""; //value.toString();
			String valArr[] = val.split("Value:");

			boolean fileExist = FileUtils.fileExist(FileUtils.readPropertyKeyValue("AppPath"));

			return (fileExist && valArr[1].trim().equals("1")) ? true : false;
		} catch (Exception e){
			System.out.println("Registry keys not available for tablet mode. probably tests are running on win OS less than 8");
			return false;
		}

	}

	public static void initialize() {
		boolean tabModeSts = false;

		try {
			//tabModeSts=detectTabletMode();
			log.info("Reading automation configuration properties...");
			InputStream inputStream = Config.class.getResourceAsStream("/automation.properties");
			Properties prop = new Properties();
			prop.load(inputStream);

			if (tabModeSts) {
				URL = FileUtils.readPropertyKeyValue("URL");
				WINDOWS_DRIVER_PATH = FileUtils.readPropertyKeyValue("WidnowDriverPath");
				APP_PATH = FileUtils.readPropertyKeyValue("AppPath");
				/* excelFilePath=System.getProperty("user.dir")+"\\src\\main\\resources";
				 excelFileName=FileUtils.readPropertyKeyValue("filename");*/

				// Start Windows Server
				Desktop desktop = Desktop.getDesktop();
				try {
					desktop.open(new File(WINDOWS_DRIVER_PATH));
					Thread.sleep(10000L);
				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} else {
				PRODUCT_URL = FileUtils.readPropertyKeyValue("ProductURL");
				BROWSER = FileUtils.readPropertyKeyValue("Browser");
				LOCALE = FileUtils.readPropertyKeyValue("Locale");
				PARALLEL = Boolean.parseBoolean(FileUtils.readPropertyKeyValue("Parallel"));
			}

			log.info("Automation configuration properties loaded.");
		} catch (IOException e) {
			log.error("Failed to read automation properties");
			e.printStackTrace();
		}

	}
}
