package utils;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.poifs.filesystem.NPOIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.simple.JSONObject;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class FileUtils {
	private static Logger log = Logger.getLogger(FileUtils.class);

	public static boolean fileExist(String filePath) {
		File f = new File(filePath);
		return f.exists() ? true : false;
	}

	public static String readPropertyKeyValue(String keyName) {
		String value = null;
		try {
			InputStream inputStream = FileUtils.class.getResourceAsStream("/automation.properties");
			Properties prop = new Properties();
			prop.load(inputStream);
			value = prop.getProperty(keyName);
		} catch (IOException e) {
			log.error("Failed to read automation properties");
			e.printStackTrace();
		}
		return value;
	}

	public static List<JSONObject> readDataFromExcel(String filePath,String fileName,String sheetName){
		File file =    new File(filePath+"\\"+fileName);
		List<JSONObject> jsonList=new ArrayList<JSONObject>();
		FileInputStream inputStream;
		Workbook workbook = null;
		Row row =null;
		try{
			inputStream = new FileInputStream(file);
			workbook = new WorkbookFactory().create(inputStream);
		}
		catch(Exception e){

		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row firstRow = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		for (int i = 1; i <=rowCount; i++) {
			JSONObject jsonObj=new JSONObject();
			row = sheet.getRow(i);
			for (int j = 0; j < firstRow.getLastCellNum(); j++) {
				if((row.getCell(j)!=null)){
					row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
					if(row.getCell(j).getStringCellValue().length()>0)
					{
						jsonObj.put(firstRow.getCell(j).getStringCellValue(), row.getCell(j).getStringCellValue());
					}
				}

			}if(!jsonObj.isEmpty())
				jsonList.add(i-1,jsonObj);
			jsonObj=null;
		}

		return jsonList;
	}

	public static LinkedHashSet<Map<String,String>> readCompleteDataFromExcel(String filePath, String fileName, String sheetName){
		File file =    new File(filePath+"\\"+fileName);
		FileInputStream inputStream;
		Workbook workbook = null;
		Row row =null;
		LinkedHashSet<Map<String,String>> myLinkedHashSet = new LinkedHashSet<Map<String,String>>();
		LinkedHashMap<String,String> objLinkedHashMap = new LinkedHashMap<String,String>();
		try{
			inputStream = new FileInputStream(file);
			workbook = WorkbookFactory.create(inputStream);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row firstRow = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		for (int i = 1; i <=rowCount; i++) {
			objLinkedHashMap = new LinkedHashMap<String,String>();
			row = sheet.getRow(i);
			for (int j = 0; j <firstRow.getLastCellNum(); j++) {
				if((firstRow.getCell(j) != null) && (!firstRow.getCell(j).getStringCellValue().trim().equals(""))){
					if((row.getCell(j) != null)){
						row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
						if(!row.getCell(j).getStringCellValue().trim().equals("")){
							objLinkedHashMap.put(firstRow.getCell(j).getStringCellValue().trim(), row.getCell(j).getStringCellValue().trim());
						}
					}
				}
			}
			if(!objLinkedHashMap.isEmpty())
				myLinkedHashSet.add(objLinkedHashMap);
			objLinkedHashMap=null;
		}
		return myLinkedHashSet;
	}

	public static String readSingleValueFromExcel(String filePath,String fileName,String sheetName,String attributeName) {
		File file =    new File(filePath+"\\"+fileName);
		String attributeValue=null;
		FileInputStream inputStream;
		Workbook workbook = null;
		Row row =null;
		try{
			inputStream = new FileInputStream(file);
			workbook = new WorkbookFactory().create(inputStream);
		}
		catch(Exception e){

		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row firstRow = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		for (int i = 1; i <2; i++) {

			row = sheet.getRow(i);
			for (int j = 0; j < firstRow.getLastCellNum(); j++) {
				if((row.getCell(j)!=null)){
					row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
					if(firstRow.getCell(j).getStringCellValue().equals(attributeName)) {
						attributeValue= row.getCell(j).getStringCellValue();
					break;
					}
				}
			}

		}

		return attributeValue;
	}


	public static List<String> readColumnDataFromExcel(String filePath,String fileName,String sheetName,String attributeName) {
		File file =    new File(filePath+"\\"+fileName);
		List<String> attributeValue=new ArrayList<String>();
		FileInputStream inputStream;
		Workbook workbook = null;
		Row row =null;
		int columnNo=0;
		try{
			inputStream = new FileInputStream(file);
			workbook = new WorkbookFactory().create(inputStream);
		}
		catch(Exception e){

		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row firstRow = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		for (int i = 1; i <=rowCount; i++) {

			row = sheet.getRow(i);
			if(i==1) {
				for (int j = 0; j < firstRow.getLastCellNum(); j++) {
					if((row.getCell(j)!=null)){
						row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
						if(firstRow.getCell(j).getStringCellValue().equals(attributeName)) {
							columnNo=j;
							break;			
						}
					}
				}
			}
				if((row.getCell(columnNo)!=null)){
					row.getCell(columnNo).setCellType(Cell.CELL_TYPE_STRING);
					if((firstRow.getCell(columnNo).getStringCellValue().equals(attributeName))&&(!row.getCell(columnNo).getStringCellValue().trim().equals(""))) {
						attributeValue.add(row.getCell(columnNo).getStringCellValue().trim());
						
					}
				}
			

		}
		return attributeValue;
	}
	public static Map<String,List<String>> readMultipleColumnDataFromExcel(String filePath,String fileName,String sheetName,List<String> attributeName) {
		File file =    new File(filePath+"\\"+fileName);
		List<String> attributeValue=new ArrayList<String>();
		Map<String,List<String>> columnValues= new HashMap<String, List<String>>();
		FileInputStream inputStream;
		Workbook workbook = null;
		Row row =null;
		try{
			inputStream = new FileInputStream(file);
			workbook = new WorkbookFactory().create(inputStream);
		}
		catch(Exception e){

		}
		Sheet sheet = workbook.getSheet(sheetName);
		Row firstRow = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		int columnNo=0;
		for(String columnName: attributeName) {
			 attributeValue=new ArrayList<String>();
			for (int i = 1; i <=rowCount; i++) {
				row = sheet.getRow(i);
				if(i==1) {
					for (int j = 0; j < firstRow.getLastCellNum(); j++) {
						if((row.getCell(j)!=null)){
							row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
							if(firstRow.getCell(j).getStringCellValue().equals(columnName)) {
								columnNo=j;
								break;
							}
						}
					}
				}
				if((row.getCell(columnNo)!=null)){
					row.getCell(columnNo).setCellType(Cell.CELL_TYPE_STRING);
					if((firstRow.getCell(columnNo).getStringCellValue().equals(columnName))&&(!row.getCell(columnNo).getStringCellValue().trim().equals(""))) {
						attributeValue.add(row.getCell(columnNo).getStringCellValue().trim());
					}
				}

			}
			columnValues.put(columnName, attributeValue);
			attributeValue=null;
		}
		return columnValues;
	}
		public static void saveDataToTheExcel(String filePath, String fileName, String sheetName, List<Map<String, String>> details){

		File file = new File(filePath+"\\"+fileName);  
		// Blank workbook
		Workbook workbook=null;
		// Create a connection to sheet
		FileInputStream inputStream;
		try{
			inputStream = new FileInputStream(file);
			workbook = new WorkbookFactory().create(inputStream);
		}
		catch(Exception e){

		}
		Sheet sheet = workbook.getSheet(sheetName);
		int counter=1;
		Cell cell=null;
		Row firstRow=sheet.getRow(0);
		for (Map<String,String> data: details) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(counter);
			for (Map.Entry<String, String> key : data.entrySet()) {
				// this line creates a cell in the next column of that row
																															
				switch(key.getKey().toLowerCase())
								{
				
				case "routeid":
					for(int i=0;i<4;i++){
						if(firstRow.getCell(i).getStringCellValue().trim().equals("RouteID"))
						{	cell=row.createCell(i);
						cell.setCellValue(key.getValue());
						}		
					}
					break;
				case "week":            		
					for(int i=0;i<4;i++){
						if(firstRow.getCell(i).getStringCellValue().trim().equals("Week"))
						{	cell=row.createCell(i);
						cell.setCellValue(key.getValue());
						}		
					}
					break;
				case "assigned to":            		
					for(int i=0;i<4;i++){
						if(firstRow.getCell(i).getStringCellValue().trim().equals("Assigned To"))
						{	cell=row.createCell(i);
						cell.setCellValue(key.getValue());
						}		
					}
					break;
				case "total inspection(s)":            		
					for(int i=0;i<4;i++){
						if(firstRow.getCell(i).getStringCellValue().trim().equals("Total Inspection(s)"))
						{	cell=row.createCell(i);
						cell.setCellValue(key.getValue());
						}		
					}
					break;
				}
			}
			counter++;
		}																															
		try {
			// This writes the workbook RouteDetailsS
			FileOutputStream out = new FileOutputStream(new File(filePath+"\\"+fileName));
			workbook.write(out);
			workbook.close();
			out.close();
			System.out.println("RouteDetails.xlsx written successfully on disk.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

public static void DataToTheExcel(String filePath, String fileName, String sheetName, List<String>		 details){

			File file = new File(filePath+"\\"+fileName);  
			// Blank workbook
			Workbook workbook=null;
			// Create a connection to sheet
			FileInputStream inputStream;
			try{
				inputStream = new FileInputStream(file);
				workbook = new WorkbookFactory().create(inputStream);
			}
			catch(Exception e){

			}
			Sheet sheet = workbook.getSheet(sheetName);
			int counter=1;
			Cell cell=null;
			Row firstRow=sheet.getRow(0);
			for( int j=1;j<details.size();j++) {
				// this creates a new row in the sheet
				Row row = sheet.createRow(counter);
				cell=row.createCell(j);
				cell.setCellValue(details.get(j));
				counter++;
			}	
			try {
				// This writes the workbook RouteDetailsS
				FileOutputStream out = new FileOutputStream(new File(filePath+"\\"+fileName));
				workbook.write(out);
				workbook.close();
				out.close();
				System.out.println("BeforeReportRun	.xlsx written successfully on disk.");
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

	
		
		
		
		
		
		
		
		
		
		
	public static int getNumberOfRecordsInColumn(String filePath,String fileName,String sheetName) {
		File file =    new File(filePath+"\\"+fileName+".xls");
		FileInputStream inputStream;
		try {
			System.out.println(Files.probeContentType(file.toPath()));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Workbook workbook = null;
		try{
		NPOIFSFileSystem fs = new NPOIFSFileSystem(file);
		
			inputStream = new FileInputStream(file);
			workbook = new HSSFWorkbook(fs.getRoot(),true);
		}
		catch(Exception e){
			e.printStackTrace();

		}
		Sheet sheet = workbook.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		return rowCount;
	}

	
	
	public static Object[][] getTestData(String filePath, String fileName,String sheetName) {
		
		File file=new File(filePath+"\\"+fileName);
		FileInputStream fis = null;
		Sheet sheet;
		Workbook workbook=null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			workbook = WorkbookFactory.create(fis);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = workbook.getSheet(sheetName);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		// System.out.println(sheet.getLastRowNum() + "--------" +
		// sheet.getRow(0).getLastCellNum());
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
				// System.out.println(data[i][k]);
			}
		}
		return data;
	}


}
	
	
	
	

