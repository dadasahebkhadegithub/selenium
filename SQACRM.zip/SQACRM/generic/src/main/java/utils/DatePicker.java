package utils;

import basePage.BasePage;
import dataHandlers.TestContext;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class DatePicker extends BasePage {

	public DatePicker(TestContext testContext) {
		super(testContext);
	}

	public void selectCurrentDateFromDatePicker(Locator datePicker) {
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		String today = Integer.toString(calendar.get(Calendar.DAY_OF_MONTH));
		List<WebElement> rows = selenium.getWebElement(datePicker)
				.findElements(By.tagName("tr"));
		int count = 0;
		for (int i = 0; i < rows.size(); i++) {
			List<WebElement> td = rows.get(i).findElements(By.tagName("td"));
			for (WebElement cell : td) {
				if (cell.getText().equals(today)) {
					cell.click();
					count++;
					break;
				}
			}
			if (count == 1) {
				break;
			}
		}
	}
	
	/*public void selectAnyDateFromPicker(String Year,String Month, String Date) {
		//Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		String today = Integer.toString(calendar.get(Calendar.DAY_OF_MONTH));
		List<WebElement> rows = selenium.getWebElement(datePicker)
				.findElements(By.tagName("tr"));
		int count = 0;
		for (int i = 0; i < rows.size(); i++) {
			List<WebElement> td = rows.get(i).findElements(By.tagName("td"));
			for (WebElement cell : td) {
				if (cell.getText().equals(today)) {
					cell.click();
					count++;
					break;
				}
			}
			if (count == 1) {
				break;
			}
		}
	}*/

}
