/**
 * @author Rajani Sinha
 */
package utils;

/*
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Locator {

	public enum Type {
		ID, NAME, CSSSELECTOR, CLASSNAME, XPATH, LINKTEXT, PARTIALLINKTEXT, TAGNAME
	}

	public Type type() default Type.ID;

	public String value();
}*/

public class Locator {

	public enum Type {
		ID, NAME, CSSSELECTOR, CLASSNAME, XPATH, LINKTEXT, PARTIALLINKTEXT, TAGNAME
	}

	public Locator(Type type, String value, String description) {
		this.type = type;
		this.value = value;
		this.description = description;
	}

	private Type type;
	private String value;
	private String description;

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Update value in existing Locator
	 * 
	 * @param replacements
	 */
	public void updateValue(String... replacements) {
		for (int i = 0; i < replacements.length; i++) {
			value = value.replace("{" + (i + 1) + "}", replacements[i]);
		}
	}

	/**
	 * Make a copy of existing Locator and Update value in new Locator instance
	 * 
	 * @param replacements
	 * @return
	 */
	public Locator updateLocator(String... replacements) {
		String newValue = this.value;
		Type newType = this.type;
		for (int i = 0; i < replacements.length; i++) {
			newValue = newValue.replace("{" + (i + 1) + "}", replacements[i]);
		}
		return new Locator(newType, newValue, this.description);
	}

	public String toString() {
		return description + "( " + type.name() + ", " + value + " )";
	}

}
