package utils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;

public class CommonPage extends BasePage{
	
	public CommonPage(TestContext testContext) {
		super(testContext);
	}

	public boolean isNextPaginationEnabled(Locator locator)
	{
		String classAttribute=selenium.getAttribute(locator, "class");
		if(classAttribute.contains("disabled"))
		{
			return false;
		}
		else
		{
			return true;
		}
		
	}
	
	public void clickNextPagination(Locator click,Locator wait) {
		selenium.getWebElement(click).findElement(By.tagName("a")).click();
		selenium.waitForElementToBeDisplayed(wait);
	}
	
	public List<WebElement> retrieveTableRows(Locator locator) {
		return selenium.getWebElement(locator).findElements(By.tagName("tr"));
	}

}
