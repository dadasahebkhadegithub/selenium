package utils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import dataHandlers.TestContext;

public class SelectUser extends CommonPage {

    public SelectUser(TestContext testContext) {
        super(testContext);
    }

    /**
     * @description: To select a User from Table
     */
    public WebElement searchUserToSelect(List<String> data, Locator nextPagination, Locator table, List<Integer> index) {
        int next = 1;
        do {
            if (isNextPaginationEnabled(nextPagination) && next > 1) {
                clickNextPagination(nextPagination, table);
            }
            next++;
            List<WebElement> tr = retrieveTableRows(table);
            for (int i = 0; i < tr.size(); i++) {
                List<WebElement> td = tr.get(i).findElements(By.tagName("td"));
                if (td.get(index.get(0)).getText().trim().equals(data.get(0)) && td.get(index.get(1)).getText().trim().equals(data.get(1)) && td.get(index.get(2)).getText().trim().equals(data.get(2))) {
                    System.out.println(td.get(index.get(0)).getText().trim());
                    System.out.println();
                    //td.get(0).findElement(By.tagName("input")).click();
                    return tr.get(i);
                }
            }
        } while (isNextPaginationEnabled(nextPagination));
        return null;
    }

    public WebElement verifySearchUser(List<String> data,  Locator table) {
       
            List<WebElement> tr = retrieveTableRows(table);
            for (int i = 0; i < tr.size(); i++) {
                List<WebElement> td = tr.get(i).findElements(By.tagName("td"));
                if (td.get(0).getText().trim().equals(data.get(0)) && td.get(1).getText().trim().equals(data.get(1)) && td.get(2).getText().trim().equals(data.get(2))) {
                    System.out.println(td.get(0).getText().trim());
                    System.out.println();
                    //td.get(0).findElement(By.tagName("input")).click();
                    return tr.get(i);
                }
            }
        
        return null;
    }
    
}
