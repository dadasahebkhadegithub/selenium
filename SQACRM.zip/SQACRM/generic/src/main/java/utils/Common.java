package utils;

import java.util.Random;

public class Common {

	public String getRandomAlphaNumericNumber() {
		// Generate random id, for example 283952-V8M32
		char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
		Random rnd = new Random();
		StringBuilder sb = new StringBuilder((100000 + rnd.nextInt(900000)) + "-");
		for (int i = 0; i < 5; i++)
			sb.append(chars[rnd.nextInt(chars.length)]);
		return sb.toString();
	}

	public static String getRandomNumber() {
		// Generate random id, for example 283952-V8M32
		char[] chars = "0123456789".toCharArray();
		Random rnd = new Random();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 7; i++)
			sb.append(chars[rnd.nextInt(chars.length)]);
		return sb.toString();
	}


}
