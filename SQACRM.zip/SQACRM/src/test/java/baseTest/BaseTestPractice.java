package baseTest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import dataHandlers.GlobalData;
import dataHandlers.TestContext;
import dataHandlers.TestData;
import pageObjects.LoginPage;
import selenium.Selenium;
import utils.Config;
import utils.FileUtils;

public class BaseTestPractice {

	protected TestData testData;
	protected  GlobalData globalData;
    public static TestContext testContext ;
    protected String testDataFilePath = getTestDataFilePath();
    protected String userName = FileUtils.readPropertyKeyValue("Username");
    public static String password = FileUtils.readPropertyKeyValue("Password");
    public static ExtentReports extent;
    public  static ExtentTest test;
    public  static ExtentTest childTest;
    //public  static ExtentTest grandchildTest;
    public  static ExtentHtmlReporter htmlReporter;
    private static String filePathEx = System.getProperty("user.dir") +"//extent_reports/" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis())) + "extentreport.html";;
   
    @BeforeSuite
    public void beforeSuite() {
        Config.initialize();
       // extent = getExtent();
        
        
        
    }
    
    @BeforeClass
	    public void beforeClass() throws Exception {
	/*        //globalData = GlobalData.getInstance();
	        testContext = new TestContext();
	        String browser = Config.BROWSER;
	        String locale = Config.LOCALE;
	        Selenium selenium = new Selenium(browser, locale);
            selenium.get();
            testContext.setSelenium(selenium);
          // extentTets();
*/            
            
           globalData = GlobalData.getInstance();
            testContext = new TestContext();
            if (!(Config.PARALLEL)) {
                testContext.setSelenium(globalData.getSelenium());
            } else {
                if (Config.detectTabletMode()) {
                    Selenium selenium = new Selenium();
                    testContext.setSelenium(selenium);
                } else {
                    String browser = Config.BROWSER;
                    String locale = Config.LOCALE;
                    Selenium  selenium = new Selenium(browser, locale);
                    selenium.get();
                    testContext.setSelenium(selenium);
                    
                	}
            	
            	}
            }
	        
 
	
	    @BeforeMethod
	    public void beforeMethod() {
	    	
	    	LoginPage  loginPage = new LoginPage(testContext);	        
	       loginPage.loginIntoTheApp(userName, password);
	    }

	    @AfterMethod
	    public void refresh() {
	      LoginPage  loginPage1 = new LoginPage(testContext);
	      loginPage1.logOut();
	    
	      testContext.getSelenium().pageRefresh();
	       
	    }

	    @AfterClass(alwaysRun = true)
	    public void afterClass() {
	        if (Config.PARALLEL) {
	        	
	            testContext.getSelenium().close();
	            testContext.getSelenium().quit();

	        }
	    }
	    
	    public static TestContext getContext() {
	        if (testContext == null)
	            testContext = new TestContext();
	        return testContext;
	    }

	    public static ExtentReports getExtent() {
	        if (extent == null) {
	            extent = new ExtentReports();//this class has constructor but here not written in my practice example they have mentioned constructor I checked version it is different  
	            
	            extent.attachReporter(getHtmlReporter());
	        }
	        return extent;
	        
	        
	    }
	    
	    
	    private static ExtentHtmlReporter getHtmlReporter() {
	        htmlReporter = new ExtentHtmlReporter(filePathEx);
	        htmlReporter.config().setChartVisibilityOnOpen(true);
	        htmlReporter.config().setTheme(Theme.STANDARD);
	        htmlReporter.config().setDocumentTitle("SQACRM Web Automation");
	        htmlReporter.config().setReportName("SQACRM  Web Automation Report");
	        
	        //ExtentHtmlReporterConfiguration a=  htmlReporter.config();
	        //htmlReporter.
	       //a.
	        
	        return htmlReporter;
	        
	    }
	    
	   /* public static ExtentTest extentTets() {
	    	test = extent.createTest(" ");
	    	return test;
	    }*/
	    
	    public String getTestDataFilePath() {
	        return System.getProperty("user.dir")+"\\testData\\SQACRM";
	    }
	
}
