package baseTest;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import dataHandlers.GlobalData;
import dataHandlers.TestContext;
import dataHandlers.TestData;
import pageObjects.LoginPage;
import selenium.Selenium;
import utils.Config;
import utils.FileUtils;

public class BaseTest {

	protected TestData testData;
    protected GlobalData globalData;
    public static TestContext testContext;
    protected String testDataFilePath = getTestDataFilePath();
    protected String userName = FileUtils.readPropertyKeyValue("Username");
    public static String password = FileUtils.readPropertyKeyValue("Password");
    
    @BeforeSuite
    public void beforeSuite() {
        Config.initialize();
    }
    
    @BeforeClass
	    public void beforeClass() throws Exception {
	        /*globalData = GlobalData.getInstance();
	        testContext = new TestContext();
	        String browser = Config.BROWSER;
	        String locale = Config.LOCALE;
	        Selenium selenium = new Selenium(browser, locale);
            testContext.setSelenium(selenium);
            selenium.get();*/
            
            
            globalData = GlobalData.getInstance();
            testContext = new TestContext();
            if (!Config.PARALLEL) {
                testContext.setSelenium(globalData.getSelenium());
            } else {
                if (Config.detectTabletMode()) {
                    Selenium selenium = new Selenium();
                    testContext.setSelenium(selenium);
                } else {
                    String browser = Config.BROWSER;
                    String locale = Config.LOCALE;
                    Selenium selenium = new Selenium(browser, locale);
                    selenium.get();
                    testContext.setSelenium(selenium);
                }
            }
	            }
	        
 
	
	    @BeforeMethod
	    public void beforeMethod() {
	        LoginPage loginPage = new LoginPage(testContext);
	        loginPage.loginIntoTheApp(userName, password);
	    }

	    @AfterMethod
	    public void refresh() {
	      LoginPage loginPage1 = new LoginPage(testContext);
	      loginPage1.logOut();
	      testContext.getSelenium().pageRefresh();
	       
	    }

	    @AfterClass(alwaysRun = true)
	    public void afterClass() {
	        if (Config.PARALLEL) {
	            testContext.getSelenium().close();
	            testContext.getSelenium().quit();

	        }
	    }
	    
	    public static TestContext getContext() {
	        if (testContext == null)
	            testContext = new TestContext();
	        return testContext;
	    }

	    public String getTestDataFilePath() {
	        return System.getProperty("user.dir")+"\\testData\\SQACRM";
	    }
	
}
