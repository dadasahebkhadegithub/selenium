package testScripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;

import baseTest.BaseTestPractice;
import pageObjects.ContactCombinedFormPage;

public class ContactCombinedFormTest extends BaseTestPractice {

	@Test(priority=1,enabled=true)
	public void createCombinedForm () {
		SoftAssert softAssert = new SoftAssert();
		ContactCombinedFormPage  combinedform =new ContactCombinedFormPage(testContext);
		childTest=test.createNode("createCombinedForm");
		combinedform.clickOnCombinedForm();
		childTest.log(Status.INFO, "Click on contact combined form");
		combinedform.enterCompnay();
		childTest.log(Status.INFO,"Entered company");
		combinedform.enterFname();
		childTest.log(Status.INFO,"Entered firstname");
		combinedform.enterSurname();
		childTest.log(Status.INFO,"Entered surname");
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		childTest.log(Status.INFO,"Entered date");
		combinedform.enterAddressTitle();
		childTest.log(Status.INFO,"Entered addressTitle");
		combinedform.enterCity();
		childTest.log(Status.INFO,"Entered city");
		combinedform.enterState();
		childTest.log(Status.INFO,"Entered state");
		combinedform.enterPostalCode();
		childTest.log(Status.INFO,"Entered postalcode");
		combinedform.clickSaveButton();
		childTest.log(Status.INFO,"Clicked on save button ");
		softAssert.assertEquals(combinedform.getCompanyLabel(), "Abc limited");
		softAssert.assertEquals(combinedform.getCombinedPageTitle(),"CRMPRO::2.0" );
		softAssert.assertAll();
	}
	
	
	

	@Test(priority=2,enabled=true)
	public void validateCombinedForm () {
		SoftAssert softAssert = new SoftAssert();
		ContactCombinedFormPage  combinedform =new ContactCombinedFormPage(testContext);
		childTest=test.createNode("validateCombinedForm");
		combinedform.clickOnCombinedForm();
		childTest.log(Status.INFO,"Click on contact combined form");
		combinedform.enterCompnay();
		childTest.log(Status.INFO, "Click on Companyname");
		combinedform.enterFname();
		childTest.log(Status.INFO, "Entered FirstName");
		//combinedform.enterSurname();
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		childTest.log(Status.INFO, "Entered date");
		combinedform.enterAddressTitle();
		childTest.log(Status.INFO, "Entered Addresstitle");
		combinedform.enterCity();
		childTest.log(Status.INFO, "Entered city");
		combinedform.enterState();
		childTest.log(Status.INFO, "Entered state");
		combinedform.enterPostalCode();
		childTest.log(Status.INFO, "Entered postalcode");
		combinedform.clickSaveButton();
		childTest.log(Status.INFO, "Entered savebutton");
		softAssert.assertEquals(combinedform.jsAlertOK(),"Please enter a last name" );
		softAssert.assertAll();
		
	}
	
	
	
	@Test(priority=3,enabled=false)
	public void validateCorrectionCombinedForm () {
		
		ContactCombinedFormPage  combinedform =new ContactCombinedFormPage(testContext);
		childTest=test.createNode("validateCorrectionCombinedForm");
		combinedform.clickOnCombinedForm();
		childTest.log(Status.INFO,"Click on contact combined form");
		combinedform.enterCompnay();
		childTest.log(Status.INFO, "Entered Companyname");
		combinedform.enterFname();
		childTest.log(Status.INFO, "Entered FirstName");
		//combinedform.enterSurname();
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		childTest.log(Status.INFO, "Entered date");
		combinedform.enterAddressTitle();
		childTest.log(Status.INFO, "Entered Addresstitle");
		combinedform.enterCity();
		childTest.log(Status.INFO, "Entered city");
		combinedform.enterState();
		childTest.log(Status.INFO, "Entered state");
		combinedform.enterPostalCode();
		childTest.log(Status.INFO, "postal code");
		combinedform.clickSaveButton();
		childTest.log(Status.INFO, "click on save button ");
		combinedform.jsAlertOK();
		childTest.log(Status.INFO, "click on alert ok button ");
		combinedform.enterSurname();
		childTest.log(Status.INFO, "Entered surname");
		combinedform.clickSaveButton();
		childTest.log(Status.INFO, "click on save button ");
		/*combinedform.enterSurname();
		combinedform.clickSaveButton();*/
	}
	
}
