package testScripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseTest.BaseTest;
import pageObjects.ContactPage;
import pageObjects.ContactWebtablePage;

public class ContactWebtableTest extends BaseTest {

	
	
	@Test(priority=1 ,enabled=false)
	public void coulmnHedars() throws InterruptedException {
		
		ContactWebtablePage webtable=new  ContactWebtablePage(testContext);
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		String str= webtable.getColumnHeaders();
		System.out.println(str);
		
		}
	
	
	@Test(priority=2,enabled=false)
	public void rowCount(){
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		ContactWebtablePage webtable=new  ContactWebtablePage(testContext);
		int size=webtable.getRowCount();
		System.out.println("Total No Of Rows:"+ size);
	}
	
	
	@Test(priority=3,enabled=false)
	public void columnCount() {
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		ContactWebtablePage webtable=new  ContactWebtablePage(testContext);
		int size=webtable.getColumnCount();
		System.out.println("Total No Of columns:"+ size);
		
	}
	
	
	@Test(priority=4,enabled=false)
	public void clickOnRowValueOfWebtable() {
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		ContactWebtablePage webtable=new  ContactWebtablePage(testContext);
		webtable.getRowValue("Rahul Malave");
		String str=	contactpage.getNewCreatedContacName();
		System.out.println("Selcted Name from contacts webtable is :"+str);
	}
	
	@Test(priority=5,enabled=true)
	public void clickEditlinkWebTable() {
		SoftAssert softAssert =new SoftAssert();
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		//ContactWebtablePage webtable=new  ContactWebtablePage(testContext);
		//webtable.clickOnRowEditlink();
		
		contactpage.selectTitle("");
		//contactpage.enterFirstName();
		//contactpage.enterLastName();
		contactpage.enterDepartment();
		contactpage.editAllowCalls();
		contactpage.editEmail();
		contactpage.editSMS();
		contactpage.selectMessagenerNetwork("");
		contactpage.selectSource("");
		contactpage.selectDate("15/August/2018");
		contactpage.selectTimeZone();
		contactpage.selectCountry();
		contactpage.clickOnSave();
		softAssert.assertEquals(contactpage.getEditedContacName(),"Deepak Patil khade","Updated Contact Sucessfully");
		softAssert.assertAll();
		
	}
	
}
