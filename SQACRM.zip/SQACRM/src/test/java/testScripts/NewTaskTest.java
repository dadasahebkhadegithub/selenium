package testScripts;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import baseTest.BaseTest;
import pageObjects.NewTaskPage;
import utils.FileUtils;

public class NewTaskTest  extends BaseTest {

	private String testDataFileName="NewTask.xlsx";
	
	@DataProvider
	public Object[][] getTaskData() {
		Object[][] data=FileUtils.getTestData(testDataFilePath, testDataFileName, "Task");
		return data;
	}
	
	
	@Test(priority=1 ,enabled=false,dataProvider="getTaskData")
	public void clickOnNewTask(String Title,String Completion,String Type,String Priority,String Identifier,String Tags,String Description) {
		
		NewTaskPage newtask=new NewTaskPage(testContext);
		
		newtask.clickOnNewTask();
		newtask.enterTitle(Title);
		newtask.enterCompletion(Completion);
		//newtask.switchWindow();
		//newtask.SwitchWinContact("Sandeep kale (No Company)");
		//newtask.SwitchWinCompany();
		newtask.selectType(Type);
		newtask.selectPriority(Priority);
		newtask.enterIndentifier(Identifier);
		newtask.enterTags(Tags);
		newtask.enterDescription(Description);
		newtask.clickSubmit();
		
		}
	
	
	
	@DataProvider
	public Object[][] getFullSearchData(){
		 Object[][] data=FileUtils.getTestData(testDataFilePath, testDataFileName, "FullSearch");
		 return data;
		}
	
	
	@Test (priority=1,enabled=true,dataProvider="getFullSearchData")
	public void clickFullSearchForm(String Title,String Priority ,String Type) {
		NewTaskPage newtask=new NewTaskPage(testContext);
		newtask.clickOnFullSearchForm();
		newtask.enterTitleFullSearch(Title);
		newtask.selectPriorityFullSearch(Priority);
		newtask.selectTypeFullSearch(Type);
		newtask.clickOnSearchButton();
		
		
		}
	
	
	
	
	
}
