package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseTest.BaseTest;
import pageObjects.LoginPage;
import utils.FileUtils;

public class LoginTest  extends  BaseTest{
	 SoftAssert softassert = new SoftAssert();
	 
	    protected String userName = FileUtils.readPropertyKeyValue("Username");
	    public static String password = FileUtils.readPropertyKeyValue("Password"); 
	    
		//LoginPage loginPage = new LoginPage(testContext);
	 
	 @Test(priority=1)
	 public void loginTest() {
	
	    // loginPage.loginIntoTheApp(userName, password);
		 
		 LoginPage loginPage = new LoginPage(testContext);
		 //loginPage.getLoggedInUserName();
		 SoftAssert softassert =new SoftAssert();
		 softassert.assertEquals(loginPage.getLoggedInUserName(), "  User: Dadasaheb Khade");
		
		/*
		 System.out.println("DK"+loginPage.getLoggedInUserName());
		 System.out.println("-------------------------------");
		 System.out.println( loginPage.getLoggedInUserName());
		 System.out.println("-------------------------------");*/
		 softassert.assertEquals(loginPage.getTitleOfLandinPage(), "CRMPRO");
		// System.out.println(loginPage.getTitleOfLandinPage());
		 Assert.assertEquals(loginPage.getLoggedInUserName(), "  User: Dadasaheb Khade");
		 softassert.assertAll();
		 
	 }
	 
	 
	 

	
}
