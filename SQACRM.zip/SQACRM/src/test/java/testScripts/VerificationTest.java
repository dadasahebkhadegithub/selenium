package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseTest.BaseTest;
import pageObjects.ContactPage;
import pageObjects.VerificationPage;

public class VerificationTest  extends BaseTest {

	
	
	@Test(priority=1 ,enabled=true)
	public void clickOnContactTest() throws InterruptedException {
		SoftAssert softAssert = new SoftAssert();
		VerificationPage verifypage=new VerificationPage(testContext);
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		softAssert.assertTrue(verifypage.isIconPresent());
		softAssert.assertTrue(verifypage.isclicktoexpand());
		softAssert.assertTrue(verifypage.tablelblPresent());
		softAssert.assertTrue(verifypage.innerTablelblPresent());
		softAssert.assertTrue(verifypage.defaultOnly());
		softAssert.assertTrue(verifypage.isShowFullFormPresent());
		softAssert.assertTrue(verifypage.isAllPresent());
		softAssert.assertTrue(verifypage.isNumPresent());
		softAssert.assertTrue(verifypage.isAPresent());
		softAssert.assertTrue(verifypage.isZPresent());
		softAssert.assertTrue(verifypage.isContactPresent());
		softAssert.assertTrue(verifypage.isExportPresent());
		softAssert.assertTrue(verifypage.isShortListAllResultPresent());
		softAssert.assertTrue(verifypage.isNewContactPresent());
		softAssert.assertTrue(verifypage.isDropDownPresent());
		softAssert.assertTrue(verifypage.isDoButtonPresent());
		softAssert.assertTrue(verifypage.isCheckBoxPresent());
		softAssert.assertTrue(verifypage.isNamePresent());
		softAssert.assertTrue(verifypage.isCompanyPresent());
		softAssert.assertTrue(verifypage.isPhonePresent());
		softAssert.assertTrue(verifypage.isHomePhonePresent());
		softAssert.assertTrue(verifypage.isMobilePresent());
		softAssert.assertTrue(verifypage.isEmailPresent());
		softAssert.assertTrue(verifypage.isOptionsPresent());
		softAssert.assertAll();
		
		}
	
	
	@Test(priority=2 ,enabled=false)
	public void clickContactTest() throws InterruptedException {
		VerificationPage verifypage=new VerificationPage(testContext);
		ContactPage contactpage=new ContactPage(testContext);
		
		contactpage.clickOnContact();
		Assert.assertTrue(verifypage.isIconPresent());
		Assert.assertTrue(verifypage.isclicktoexpand());
		Assert.assertTrue(verifypage.isShowFullFormPresent());
		Assert.assertTrue(verifypage.isAllPresent());
		Assert.assertTrue(verifypage.isNumPresent());
		
		Assert.assertTrue(verifypage.isAPresent());
		
		Assert.assertTrue(verifypage.isZPresent());
		Assert.assertTrue(verifypage.isContactPresent());
		Assert.assertTrue(verifypage.isExportPresent());
		Assert.assertTrue(verifypage.isShortListAllResultPresent());
		Assert.assertTrue(verifypage.isNewContactPresent());
		Assert.assertTrue(verifypage.isDropDownPresent());
		Assert.assertTrue(verifypage.isDoButtonPresent());
		Assert.assertTrue(verifypage.isCheckBoxPresent());
		Assert.assertTrue(verifypage.isNamePresent());
		Assert.assertTrue(verifypage.isCompanyPresent());
		Assert.assertTrue(verifypage.isPhonePresent());
		Assert.assertTrue(verifypage.isHomePhonePresent());
		Assert.assertTrue(verifypage.isMobilePresent());
		Assert.assertTrue(verifypage.isEmailPresent());
		Assert.assertTrue(verifypage.isOptionsPresent());
		
		}
	
	
	@Test(priority=3 ,enabled=false)
	public void verifyCollapseExpand() throws InterruptedException {
		SoftAssert softAssert = new SoftAssert();
		VerificationPage verifypage=new VerificationPage(testContext);
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		verifypage.clickOnIcon();
		softAssert.assertTrue(verifypage.isCollapseBtnDisplyed());
		
		softAssert.assertAll();
		
	
	}

	
	
	
	
	
	
	
	
	
}
