package testScripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;

import baseTest.BaseTestPractice;
import pageObjects.ContactWebtablePage;
import pageObjects.FullSearchFormPage;

public class FullSearchFormTest extends BaseTestPractice {

	
	
	@Test(priority=1,enabled=true)
		public void clickOnFullSearchForm () {
		SoftAssert softassert =new SoftAssert();
		FullSearchFormPage fullsearchformpage=new FullSearchFormPage(testContext);
		childTest=test.createNode("clickOnFullSearchForm");
		fullsearchformpage.clickOnFullSearchForm();
		childTest.log(Status.INFO, "Click on fullsearchform");
		softassert.assertEquals(fullsearchformpage.getSearchContactLable(), "Search Contact");
		softassert.assertAll();
		}
	
	

	@Test(priority=2,enabled=true)
		public void search () {
		SoftAssert softassert =new SoftAssert();
		FullSearchFormPage fullsearchformpage=new FullSearchFormPage(testContext);
		ContactWebtablePage webtable=new ContactWebtablePage(testContext);
		childTest=test.createNode("search");
		fullsearchformpage.clickOnFullSearchForm();
		childTest.log(Status.INFO, "Click on fullsearchform");
		fullsearchformpage.enterFirstName();
		childTest.log(Status.INFO, "Entered firstname");
		fullsearchformpage.enterSurname();
		childTest.log(Status.INFO, "Entered surname");
		fullsearchformpage.clickOnSearch();
		childTest.log(Status.INFO, "click on search");
		fullsearchformpage.waitPageLoad();
		softassert.assertEquals(fullsearchformpage.getContatLable(), "Contacts"); 
		softassert.assertEquals(webtable.getRowValues("Dadasaheb Khade"),"Dadasaheb Khade");
		softassert.assertAll();
		
		
		}
	
	@Test(priority=3,enabled=false)
	public void VerifySearchRecords () {
	SoftAssert softassert =new SoftAssert();
	FullSearchFormPage fullsearchformpage=new FullSearchFormPage(testContext);
	ContactWebtablePage webtable=new ContactWebtablePage(testContext);
	childTest=test.createNode("VerifySearchRecords");
	fullsearchformpage.clickOnFullSearchForm();
	childTest.log(Status.INFO, "Click on fullsearchform");
	fullsearchformpage.enterFirstName();
	childTest.log(Status.INFO, "Entered firstname");
	fullsearchformpage.enterSurname();
	childTest.log(Status.INFO, "Entered surname");
	fullsearchformpage.clickOnSearch();
	childTest.log(Status.INFO, "click on search");
	fullsearchformpage.waitPageLoad();
	webtable.getRowValueClick("Dadasaheb Khade");
	childTest.log(Status.INFO, "click on result value");
	//fullsearchformpage.getClickUsername();
	softassert.assertEquals(fullsearchformpage.getClickUsername(), "Dadasaheb K"); 
	childTest.log(Status.INFO, "Verify result value of clicked record");
	softassert.assertAll();
	
	}
	
	
	
}
