package testScripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import baseTest.BaseTest;
import pageObjects.ContactPage;

public class CreateContactParametersTest extends BaseTest {

	
	@Parameters({"Title","FirstName","MiddleName","LastName"})
	@Test(priority=1 ,enabled=true)
	public void clickOnContactTestByParametrsTest1(String Title,String FirstName,String MiddleName,String LastName)  {
		
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		contactpage.clickOnNewContact();
		contactpage.selectTitle(Title);
		contactpage.enterFirstName(FirstName);
		contactpage.enterMiddleName(MiddleName);
		contactpage.enterLastName(LastName);
		contactpage.clickOnSave();
		
		}
	
	
	
	@Parameters({"Title","FirstName","MiddleName","LastName"})
	@Test(priority=2 ,enabled=true)
	public void clickOnContactTestByParametrsTest2(String Title,String FirstName,String MiddleName,String LastName)  {
		
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		contactpage.clickOnNewContact();
		contactpage.selectTitle(Title);
		contactpage.enterFirstName(FirstName);
		contactpage.enterMiddleName(MiddleName);
		contactpage.enterLastName(LastName);
		contactpage.clickOnSave();
		
		}
	
	
	
	@Parameters({"Title","FirstName"})
	@Test(priority=3 ,enabled=true)
	public void clickOnContactTestByParametrsTest4(String Title,String FirstName)  {
		
		ContactPage contactpage=new ContactPage(testContext);
		contactpage.clickOnContact();
		contactpage.clickOnNewContact();
		contactpage.selectTitle(Title);
		contactpage.enterFirstName(FirstName);
		contactpage.enterMiddleName("R");
		contactpage.enterLastName("Ronaldo");
		contactpage.clickOnSave();
		
		}
	
	
	  @Test(priority=4,enabled=true)
	     @Parameters({"Title","FirstName","MiddleName","LastName","Suffix","Category"})
		public void createNewContactTestByParameterTest3(String Title,String FirstName,String MiddleName,String LastName,String Suffix,String Category) {
			
			ContactPage contactpage=new ContactPage(testContext);
			
			contactpage.clickOnNewContact();
			contactpage.selectTitle(Title);
			contactpage.enterFirstName(FirstName);
			contactpage.enterMiddleName(MiddleName);
			contactpage.enterLastName(LastName);
			contactpage.selectSuffix(Suffix);
			contactpage.selectCategoryByParameters(Category);
			contactpage.selectReceviedEmail();
			contactpage.selectReceviedSms();
			contactpage.selectAllowCalls();
			contactpage.scroll();
			contactpage.scrollUp();
			contactpage.clickOnSave();
			
			
		}

	  @Parameters({"MessengerNetwork","Source"})
		@Test(priority=5 ,enabled=true)
		public void clickOnContactTestByParametrsTest5(String MessengerNetwork,String Source )  {
			
			ContactPage contactpage=new ContactPage(testContext);
			contactpage.clickOnContact();
			contactpage.clickOnNewContact();
			contactpage.selectTitle("Mr.");
			contactpage.enterFirstName("Ricky");
			contactpage.enterMiddleName("R");
			contactpage.enterLastName("Ronaldo");
			contactpage.selectMessagenerNetwork(MessengerNetwork);
			contactpage.selectSource(Source);
			contactpage.clickOnSave();
			}
	
}
