package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTest.BaseTest;
import pageObjects.TaskPage;

public class TaskTest extends BaseTest {

	
	@Test(priority=1 ,enabled=true)
	public void clickOnTask()  {
		
		TaskPage newtask=new TaskPage(testContext);
		
		newtask.clickOnTask();
		newtask.lbltext();
		Assert.assertTrue(newtask.deleSavelbl());
		
		}
	
	
	@Test(priority=2 ,enabled=false)
	
	public void searchTask() {
		
		TaskPage newtask=new TaskPage(testContext);
		
		newtask.clickOnTask();
		newtask.enterCompletion();
		newtask.selectStatus();
		newtask.enterCompany();
		newtask.clickSubmit();
		
		
		}
	
	
	@Test(priority=3 ,enabled=false)
	public void validateSearchResult()  {
		
		TaskPage newtask=new TaskPage(testContext);
		
		newtask.clickOnTask();
		newtask.enterCompletion();
		newtask.selectStatus();
		newtask.enterCompany();
		newtask.clickOnSaveSearch();
		newtask.clickSubmit();
		
		Assert.assertEquals(newtask.searchResultGrid(),"10013");
		
		}
	
	
	
	
	
}
