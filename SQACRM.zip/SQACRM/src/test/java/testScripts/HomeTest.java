package testScripts;

import baseTest.BaseTest;
import pageObjects.HomePage;

public class HomeTest extends  BaseTest {
	HomePage homepage=new HomePage(testContext);
}

