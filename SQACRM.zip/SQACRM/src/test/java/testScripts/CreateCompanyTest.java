package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;

import baseTest.BaseTestPractice;
import pageObjects.CreateCompanyPage;

public class CreateCompanyTest  extends BaseTestPractice {

	@Test(priority=1,enabled=true)
	public void clickOnNewCompanyTest() {
		SoftAssert softAssert = new SoftAssert();
		
		CreateCompanyPage companypage=new CreateCompanyPage(testContext);
		//test=test.createNode("clickOnNewCompanyTest");
		companypage.clickOnNewCompany();
		//childTest.log(Status.INFO, "Click on New Companay");
		companypage.enterCompany();
		//childTest.log(Status.INFO, "Enterd company name ");
		companypage.enterIndustry();
		//childTest.log(Status.INFO, "Entered Industry ");
		companypage.enterEmployee();
		//childTest.log(Status.INFO, "Entered employee ");
		companypage.selectStatus();
		//childTest.log(Status.INFO, "select status ");
		companypage.selectCategory();
		//childTest.log(Status.INFO, "select category ");
		companypage.enterPhone();
		//childTest.log(Status.INFO, "entered phone  ");
		companypage.enterWebSite();
		//childTest.log(Status.INFO, "entered website ");
		companypage.enterAddressTitle();
		//childTest.log(Status.INFO, "entered addresstitle ");
		companypage.enterState();
		//childTest.log(Status.INFO, "entered state ");
		companypage.enterPostCode();
		//childTest.log(Status.INFO, "entered postcode");
		companypage.clickSubmit();
		//childTest.log(Status.INFO, "Click on submit button");
		softAssert.assertEquals(companypage.getCreatedCompanyName(),"Company: TCS Technology" );
		softAssert.assertEquals(companypage.getCompanyPageTitle(),"CRMPRO :: 2.0");
		softAssert.assertAll();
}
	
	@Test(priority=2,enabled=true)
	public void verifyNewCreatedCompanyTest() {
		
		CreateCompanyPage companypage=new CreateCompanyPage(testContext);
		//test=test.createNode("verifyNewCreatedCompanyTest");
		companypage.clickOnNewCompany();
		//childTest.log(Status.INFO, "Click on new company");
		companypage.enterCompany();
		//.log(Status.INFO, "Enterd company name ");
		companypage.enterIndustry();
		//childTest.log(Status.INFO, "Entered Industry ");
		companypage.enterEmployee();
		//childTest.log(Status.INFO, "Entered employee ");
		companypage.selectStatus();
		//childTest.log(Status.INFO, "select status ");
		companypage.selectCategory();
		//childTest.log(Status.INFO, "select category ");
		companypage.enterPhone();
		//childTest.log(Status.INFO, "entered phone  ");
		companypage.enterWebSite();
		//.log(Status.INFO, "entered website ");
		companypage.enterAddressTitle();
		//childTest.log(Status.INFO, "entered addresstitle ");
		companypage.enterState();
		//childTest.log(Status.INFO, "entered state ");
		companypage.enterPostCode();
		//childTest.log(Status.INFO, "entered postcode");
		companypage.clickSubmit();
		//childTest.log(Status.INFO, "Click on submit button");
		Assert.assertTrue(companypage.lblPresent());
		
}
	
	//Write the test case for edit and delete 
	
}
