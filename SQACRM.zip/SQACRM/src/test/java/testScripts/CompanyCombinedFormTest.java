package testScripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseTest.BaseTest;
import pageObjects.CompanyCombinedFormPage;
import pageObjects.ContactCombinedFormPage;

public class CompanyCombinedFormTest extends BaseTest {

	
	@Test(priority=1,enabled=false)
	public void createCombinedForm () {
		
		CompanyCombinedFormPage  combinedform =new CompanyCombinedFormPage(testContext);
		combinedform.clickOnCombinedForm();
		combinedform.enterCompnay();
		combinedform.enterFname();
		combinedform.enterSurname();
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		combinedform.enterAddressTitle();
		combinedform.enterCity();
		combinedform.enterState();
		combinedform.enterPostalCode();
		combinedform.clickSaveButton();
	
	
	}
	
	
	

	@Test(priority=2,enabled=true)
	public void validateCombinedForm () {
		SoftAssert softAssert = new SoftAssert();
		CompanyCombinedFormPage  combinedform =new CompanyCombinedFormPage(testContext);
		combinedform.clickOnCombinedForm();
		combinedform.enterCompnay();
		combinedform.enterFname();
		//combinedform.enterSurname();
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		combinedform.enterAddressTitle();
		combinedform.enterCity();
		combinedform.enterState();
		combinedform.enterPostalCode();
		combinedform.clickSaveButton();
		//combinedform.jsAlertOK();
		softAssert.assertEquals(combinedform.jsAlertOK(),"Please enter a last name" );
		
		softAssert.assertAll();
		
	}
	
	
	
	@Test(priority=3,enabled=false)
	public void validateCorrectionCombinedForm () {
		
		CompanyCombinedFormPage  combinedform =new CompanyCombinedFormPage(testContext);
		combinedform.clickOnCombinedForm();
		combinedform.enterCompnay();
		combinedform.enterFname();
		//combinedform.enterSurname();
		combinedform.srollDown();
		//combinedform.waitToEnterDate();
		combinedform.enterDate();
		combinedform.enterAddressTitle();
		combinedform.enterCity();
		combinedform.enterState();
		combinedform.enterPostalCode();
		combinedform.clickSaveButton();
		combinedform.JSPopUP();
		combinedform.enterSurname();
		combinedform.clickSaveButton();
		
	}
	
}
