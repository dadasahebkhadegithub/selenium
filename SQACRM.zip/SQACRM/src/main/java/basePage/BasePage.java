package basePage;

import org.apache.log4j.Logger;

import dataHandlers.TestContext;
import selenium.Selenium;
import utils.Locator;

public class BasePage {

	protected TestContext testContext;
	protected Selenium selenium;
	protected Logger log;

	
	public BasePage(TestContext testContext) {
		this.testContext = testContext;
		selenium = testContext.getSelenium();
		log = Logger.getLogger(this.getClass());
	}
	
}
