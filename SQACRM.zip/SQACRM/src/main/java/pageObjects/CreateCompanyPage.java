package pageObjects;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class CreateCompanyPage extends BasePage{

	
	public CreateCompanyPage(TestContext testContext) {
        super(testContext);

    }
	
/**************************************Locators************************************************/	
	  
	String frame_name="mainpanel";
	private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
	
	
	private Locator link_company = new Locator(Type.XPATH,"//a[contains(text(),'Companies')]","contactbutton");
	private Locator link_new_company = new Locator(Type.XPATH,"//a[contains(text(),'New Company')]","contactbutton");
	
	private Locator txt_companyname =new Locator(Type.XPATH,"//input[@id='company_name']","contactbutton");
	
	  private Locator txt_industry =new Locator(Type.XPATH,"//input[@name='industry']","contactbutton");
	 
	  private Locator txt_employess =new Locator(Type.XPATH,"//input[@name='num_of_employees']","contactbutton");
	
	  private Locator txt_status =new Locator(Type.XPATH,"//select[@name='status']","contactbutton");
	
	  private Locator txt_category =new Locator(Type.XPATH,"//select[@name='category']","contactbutton");
		
	  private Locator txt_phone =new Locator(Type.XPATH,"//input[@name='phone']","contactbutton");	
		
	  private Locator txt_website =new Locator(Type.XPATH,"//input[@name='website']","contactbutton");
	 
	  private Locator txt_title =new Locator(Type.XPATH,"//input[@name='address_title']","contactbutton");
	  
	  private Locator txt_city =new Locator(Type.XPATH,"//input[@name='city']","contactbutton");
	 
	  private Locator txt_state =new Locator(Type.XPATH,"//input[@name='state']","contactbutton");
		 
	  private Locator txt_postcode = new Locator(Type.XPATH,"//input[@name='postcode']","contactbutton");
		
	  private Locator txt_submit = new Locator(Type.XPATH,"//form[@name='companyForm']//table/tbody/tr[1]/td[1]/input[@type='submit']","contactbutton");
	
	
	  private Locator cmp_name = new Locator(Type.XPATH,"//*[@id='vSummary']/descendant::table[2]/tbody/tr[1]/td[1]","contactbutton");


	  private Locator lbl_company = new Locator(Type.XPATH,"//td[contains(text(),'Company: TCS Technology')]","contactbutton"); 
	
	/**********************************Unit Functions******************************************/
	 
	  public void clickOnNewCompany() {
		  
			selenium.switchToFrameToClick(iframe,link_company,link_new_company, frame_name);
			
		 }
	
	  public void enterCompany() {
		  selenium.switchToFrame(frame_name);
		  selenium.sendKey(txt_companyname, "TCS Technology");
	  }
	  
	  
	  public void enterIndustry() {
		  
		  selenium.sendKey(txt_industry, "SOftware");
	  }
	  
	  
	  
	  public void enterEmployee() {
		  
		  selenium.sendKey(txt_employess, "500");
	  }
	  
	  public void selectStatus() {
		  
		  selenium.selectByVisibleText(txt_status, "New");
	  }
	  
	
	  public void selectCategory() {
		  
		  selenium.selectByVisibleText(txt_category, "Partner");
	  }
	  
public void enterPhone() {
		  
		  selenium.sendKey(txt_phone, "99999999");
	  }
	
public void enterWebSite() {
	  
	  selenium.sendKey(txt_website, "WWW.TCS.com");
}


public void enterAddressTitle() {
	  
	  selenium.sendKey(txt_title, "102,IT Park .Mumbai");
}

public void enterCity() {
	  
	  selenium.sendKey(txt_city, "MUmbaii");
}


public void enterState() {
	  
	  selenium.sendKey(txt_city, "Maharashtra");
}


public void enterPostCode() {
	  
	  selenium.sendKey(txt_postcode, "022237795");
}

public void clickSubmit(){
	  
	  selenium.getWebElement(txt_submit).click();
}


public boolean  lblPresent() {
	return selenium.isElementDisplayed(lbl_company);
	
}

public String getCreatedCompanyName() {
	
	return selenium.getWebElement(lbl_company).getText().trim();
}


public String getCompanyPageTitle() {
	return selenium.getTitle().trim();
}



}
