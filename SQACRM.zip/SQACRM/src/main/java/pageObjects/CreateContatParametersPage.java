package pageObjects;

import basePage.BasePage;
import dataHandlers.TestContext;

public class CreateContatParametersPage extends BasePage{

	 public CreateContatParametersPage (TestContext testContext) {
	        super(testContext);
	 	}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
