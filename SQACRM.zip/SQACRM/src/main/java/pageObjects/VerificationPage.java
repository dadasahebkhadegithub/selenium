package pageObjects;

import java.util.List;

import org.openqa.selenium.WebElement;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class VerificationPage extends BasePage {

	 public VerificationPage(TestContext testContext) {
	        super(testContext);

	
	}
	 
/*************************************Locators**********************************************/	 
	 
String frame_name="mainpanel";
private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
private Locator icon_button = new Locator(Type.XPATH,"//input[@id='btn_cs_search']","contactbutton");
private Locator btn_showfullform = new Locator(Type.XPATH,"//input[@value='Show Full Form']","contactbutton");	 
private Locator txt_clicktoexpand = new Locator(Type.XPATH,"//small[text()='(click to expand)']	","contactbutton");	 	 
private Locator link_All = new Locator(Type.XPATH,"//td[text()='All']","contactbutton");	 	
private Locator link_Num = new Locator(Type.XPATH,"//td[text()='Num']","contactbutton");	 
private Locator link_A = new Locator(Type.XPATH,"//td[text()='A']","contactbutton");	 
private Locator link_Z = new Locator(Type.XPATH,"//td[text()='Z']","contactbutton");	 
private Locator link_lblcontact = new Locator(Type.XPATH,"//td[contains(text(),'Contacts')]","contactbutton");
private Locator link_Export = new Locator(Type.XPATH,"//input[@value='Export']","contactbutton");
private Locator link_ShortlistAllResult = new Locator(Type.XPATH,"//input[@value='Shortlist All Results']","contactbutton");
private Locator link_NewContact = new Locator(Type.XPATH,"//input[@value='New Contact']","contactbutton");
private Locator drpdw_doaction = new Locator(Type.XPATH,"//select[@name='do_action']","contactbutton");
private Locator btn_do = new Locator(Type.XPATH,"//input[@value='DO']","contactbutton");
private Locator chk_box_btn = new Locator(Type.XPATH,"//form[@id='vContactsForm']/table/tbody/tr[3]/td[1]","contactbutton");
private Locator link_Name = new Locator(Type.XPATH,"//strong[text()='Name']","contactbutton");
private Locator link_Company = new Locator(Type.XPATH,"//strong[text()='Company']","contactbutton");
private Locator link_Phone = new Locator(Type.XPATH,"//strong[text()='Phone']","contactbutton");
private Locator link_HomePhone = new Locator(Type.XPATH,"//strong[text()='Home Phone']","contactbutton");
private Locator link_Mobile = new Locator(Type.XPATH,"//strong[text()='Mobile']","contactbutton");
private Locator link_Email = new Locator(Type.XPATH,"//strong[text()='Email']","contactbutton");
private Locator link_Options = new Locator(Type.XPATH,"//strong[text()='Options']","contactbutton");

private Locator lbl_status = new Locator(Type.XPATH,"//td[text()='Status']","contactbutton");
private Locator lbl_category = new Locator(Type.XPATH,"//td[text()='Category']","contactbutton");

private Locator lbl_owner = new Locator(Type.XPATH,"//td[text()='Owner']","contactbutton");
private Locator lbl_tags = new Locator(Type.XPATH,"//strong[text()='Tags']","contactbutton");


private Locator innertable_lbl = new Locator(Type.XPATH,"//*[@id='extendedSearchLayer']/table/tbody/tr[1]/td","contactbutton");



private Locator  defaultOnly_lbl = new Locator(Type.XPATH,"//*[@id='extendedSearchLayer']/descendant::table[3]/tbody/tr[4]/td[2]","contactbutton");

private Locator btn_collapse = new Locator(Type.XPATH,"//input[@id='btn_cs_search' and @value='+']","contactbutton");

private Locator tbl_heading = new Locator(Type.XPATH,"//form[@name='CONTACTSEARCH']/descendant::table[1]/tbody/tr[1]/td[1]","contactbutton");




/*************************************************Unit Actions ******************************************************/


public boolean isIconPresent() {
	selenium.switchToFrame(frame_name);
	return selenium.isElementPresent(icon_button);
}

public boolean isclicktoexpand() {
	return selenium.isElementPresent(txt_clicktoexpand);
	//return selenium.isElementDisplayed(txt_clicktoexpand);

}

public boolean tablelblPresent() {
	
	String str=selenium.getWebElement(tbl_heading).getText();
	System.out.println(str);
	return selenium.isElementPresent(tbl_heading);
	//return selenium.isElementDisplayed(txt_clicktoexpand);

}

public boolean isShowFullFormPresent() {
	return selenium.isElementPresent(btn_showfullform);
	//return selenium.isElementDisplayed(btn_showfullform);
}

public boolean innerTablelblPresent() {
	
	String str=selenium.getWebElement(innertable_lbl).getText();
	System.out.println(str);
	return selenium.isElementPresent(innertable_lbl);
	//return selenium.isElementDisplayed(txt_clicktoexpand);

}

public boolean defaultOnly() {
	
	/*List<WebElement> ele =selenium.getWebElements(defaultOnly_lbl);
	
	for (WebElement e:ele) {
		
	String str =e.getText();
	
	System.out.println(str);
	
	}
	*/
	
	String str=selenium.getWebElement(defaultOnly_lbl).getText();
	 boolean flag=false;
	   
	 
	 char[] strArray = str.toCharArray();  
     StringBuffer stringBuffer = new StringBuffer();  
     for (int i = 0; i < strArray.length; i++) {  
         if ((strArray[i] != ' ') && (strArray[i] != '\t'))  {  
             stringBuffer.append(strArray[i]);  
         }  
     } 
     
     String noSpaceStr2 = stringBuffer.toString();  
     String str1[]=noSpaceStr2.split("\n");
     for (int i=0;i<str1.length;i++) {
    	 
    	 System.out.println(str1[i]);
    	 String str2="Defaultonly";
    	 if (str1[i].equals(str2) ) {
    		flag=true;
    	 }
     }
     
     
     noSpaceStr2=noSpaceStr2.replaceAll("\n", "");
     System.out.println(noSpaceStr2);  
     
	return flag;
	//return selenium.isElementDisplayed(txt_clicktoexpand);

}

public boolean isAllPresent() {
	//return selenium.isElementPresent(link_All);
	return selenium.isElementDisplayed(link_All);
}

public boolean isNumPresent() {
	return selenium.isElementPresent(link_Num);
}

public boolean isAPresent() {
	return selenium.isElementPresent(link_A);
}

public boolean isZPresent() {
	return selenium.isElementPresent(link_Z);
}


public boolean isContactPresent() {
	return selenium.isElementPresent(link_lblcontact);
}

public boolean isExportPresent() {
	return selenium.isElementPresent(link_Export);
}


public boolean isShortListAllResultPresent() {
	return selenium.isElementPresent(link_ShortlistAllResult);
}


public boolean isNewContactPresent() {
	return selenium.isElementPresent(link_NewContact);
}


public boolean isDropDownPresent() {
	return selenium.isElementPresent(drpdw_doaction);
}

public boolean isDoButtonPresent() {
	return selenium.isElementPresent(btn_do);
}

public boolean isCheckBoxPresent() {
	return selenium.isElementPresent(chk_box_btn);
}


public boolean isNamePresent() {
	return selenium.isElementPresent(link_Name);
}

public boolean isCompanyPresent() {
	return selenium.isElementPresent(link_Company);
}

public boolean isPhonePresent() {
	return selenium.isElementPresent(link_Company);
}

public boolean isHomePhonePresent() {
	return selenium.isElementPresent(link_HomePhone);
}


public boolean isMobilePresent() {
	return selenium.isElementPresent(link_Mobile);
}

public boolean isEmailPresent() {
	return selenium.isElementPresent(link_Email);
}


public boolean isOptionsPresent() {
	return selenium.isElementPresent(link_Options);
}


public  boolean isStatusDisplyed() {
	return selenium.isElementDisplayed(lbl_status);
}

public  boolean isCategoryDisplyed() {
	return selenium.isElementDisplayed(lbl_category);
	
}

public  boolean isOwnerDisplyed() {
	return selenium.isElementDisplayed(lbl_owner);
	
}

public  boolean isCollapseBtnDisplyed() {
	
	return selenium.isElementDisplayed(btn_collapse);
}

public void clickOnIcon() {
	selenium.switchToFrame(frame_name);
	selenium.getWebElement(icon_button).click();
	selenium.getWebElement(icon_button).click();
}

}
