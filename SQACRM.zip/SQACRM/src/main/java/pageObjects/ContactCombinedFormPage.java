package pageObjects;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class ContactCombinedFormPage extends BasePage {

	public ContactCombinedFormPage(TestContext testContext) {
        super(testContext);

    }
	
	/******************************Locators ***************************************/
	
	 public String frame_name="mainpanel";
	 private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
	 private Locator link_contact = new Locator(Type.XPATH,"//a[contains(text(),'Contacts')]","contactbutton");
	 //private Locator link_new_contact = new Locator(Type.XPATH,"//a[contains(text(),'Combined Form')]","contactbutton");
	 private Locator lbl_combinedform = new Locator(Type.XPATH,"//legend[text()='Combined Contact and Company Form']","contactbutton");
	 private Locator txt_company = new Locator(Type.XPATH,"//input[@id='company_name']","contactbutton");
	 private Locator txt_fname = new Locator(Type.XPATH,"//input[@id='first_name']","contactbutton");
	 private Locator txt_surname = new Locator(Type.XPATH,"//input[@id='surname']","contactbutton");
	
	 private Locator txt_calendar = new Locator(Type.XPATH,"//input[@id='fieldId_birthday']","contactbutton");

	
	 private Locator btn_save = new Locator(Type.XPATH,"//*[@id='combinedForm']/fieldset/table/tbody/tr[1]/td/input","contactbutton");
	 
	 
	
	 private Locator link_combinedform = new Locator(Type.XPATH,"//div[@id='navmenu']/ul/li[4]/ul/li[2]/a","contactbutton");
	 
	 
	 
	 private Locator txt_addresTitle =new Locator(Type.XPATH,"//input[@name='address_title']","contactbutton");

	 private Locator txt_city =new Locator(Type.XPATH,"//input[@name='city']","contactbutton");

	
	 private Locator txt_state =new Locator(Type.XPATH,"//input[@name='state']","contactbutton");
	 
	 private Locator txt_postcode = new Locator(Type.XPATH,"//input[@name='postcode']","contactbutton");
	
	 
	 private Locator lbl_company = new Locator(Type.XPATH,"//a[text()='Sony Technology']","contactbutton");

	 
	/******************************************Unit Action ************************************************************/ 
	 
	 
	 
	 public void clickOnCombinedForm() {
			selenium.switchToFrameToClick(iframe,link_contact,link_combinedform, frame_name);
			
		 }
	 
	 
	 public void enterCompnay() {
		 selenium.switchToFrame(frame_name);
		 selenium.sendKey(txt_company, "Sony Technology");
	 }
	 
	 public void enterFname() {
		 
		 selenium.sendKey(txt_fname, "Sammer");
	 }
	 
	 public void enterSurname() {
		 
		 selenium.sendKey(txt_surname, "Bhoite");
	 }
	
	 
	 public void enterDate() {
		 selenium.sendKeysWithJS(txt_calendar, "27-Feb-1982");
	 }
	
	 public void clickSaveButton() {
		 selenium.getWebElement(btn_save).click();
	 }
 	 
	 public void srollDown() {
		 selenium.scrollDownToTheEndOfPage();
	 }
	 
	 public void enterAddressTitle() {
		 selenium.sendKey(txt_addresTitle, "131,Mital Industrial estate");
	 }
	 
	 
	 public void enterCity() {
		 selenium.sendKey(txt_city, "Mumbai");
	 }
	 
	 public void enterState() {
		 selenium.sendKey(txt_state, "Maharashtra");
	 }
	 
	 
	 public void enterPostalCode() {
		 selenium.sendKey(txt_postcode, "022372237");
	 }
	 
	 
	
	 public String  jsAlertOK() {
		return  selenium.switchToAlertOK(frame_name);
	
		
	 }
	
	 public String getCompanyLabel() {
		 return selenium.getWebElement(lbl_company).getText().trim();
	 }
	 
	 public String getCombinedPageTitle() {
			return selenium.getTitle().trim();
		}
}
