package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class NewTaskPage extends BasePage {
	
	
	public NewTaskPage(TestContext testContext) {
        super(testContext);

    }
	

/***************************************Locators******************************************************/

String frame_name="mainpanel";
private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
private Locator link_task = new Locator(Type.XPATH,"//a[contains(text(),'Tasks')]","contactbutton");
private Locator link_NewTask= new Locator(Type.XPATH, "//a[text()='New Task']","new contact form");	


private Locator txt_title= new Locator(Type.XPATH, "//input[@id='title']","new contact form");		
private Locator txt_completion= new Locator(Type.XPATH, "//input[@id='completion']","new contact form");


private Locator btn_companylookup= new Locator(Type.XPATH, "//*[@id='taskForm']//following::table[3]/tbody/tr[4]/td[2]/input[4]","new contact form");



private Locator btn_contactlookup= new Locator(Type.XPATH, "//*[@id='taskForm']//following::table[3]/tbody/tr[3]/td[2]/input[4]","new contact form");


private Locator btn_save = new Locator(Type.XPATH,"//*[@id='taskForm']/table/tbody/tr[1]/td/input","contactbutton");


private Locator txt_tags = new Locator(Type.XPATH,"//input[@name='tags']","contactbutton");


private Locator date_deadline  = new Locator(Type.XPATH,"//input[@id='fieldId_deadline']","contactbutton");

private Locator txt_description  = new Locator(Type.XPATH,"//textarea[@name='description']","contactbutton");

private Locator ddl_task = new Locator(Type.XPATH,"//select[@name='task_type']","contactbutton");


private Locator ddl_priority = new Locator(Type.XPATH,"//select[@name='priority']","contactbutton");

private Locator txt_identifier = new Locator(Type.XPATH,"//input[@name='identifier']","contactbutton");





/************************************  Full Search Form  ****************************************/
private Locator link_fullsearchform = new Locator(Type.XPATH,"//*[@id='navmenu']/ul/li[6]/ul/li[2]/a","contactbutton");
private Locator txt_keyword = new Locator(Type.XPATH,"//input[@name='cs_keyword']","contactbutton");
private Locator ddlsearch_priority = new Locator(Type.XPATH,"//select[@name='cs_priority']","contactbutton");
private Locator ddlsearch_tasktype = new Locator(Type.XPATH,"//select[@name='cs_task_type']","contactbutton");

private Locator btn_search_task = new Locator(Type.XPATH,"//form[@name='taskForm']//table/tbody/tr[1]/td[1]/input[1]","contactbutton");

/*************************************Browser window locators*****************************************************/

private Locator btn_search = new Locator(Type.XPATH,"//input[@id='search']","contactbutton");

private Locator btn_submit = new Locator(Type.XPATH,"//input[@type='submit']","contactbutton");

private Locator link = new Locator(Type.XPATH,"//table/tbody/tr[3]/td/table/tbody/tr[2]/td/a","contactbutton");

private Locator tbl = new Locator(Type.XPATH,"//table/tbody/tr[3]/td/table/tbody/tr[2]/td/a","contactbutton");


/**********************************Unit Actions ********************************************************************/
	
public void clickOnNewTask() {
	selenium.switchToFrameToClick(iframe,link_task,link_NewTask, frame_name);
	
 }	





public void enterTitle(String str) {
	selenium.switchToFrame(frame_name);
	selenium.sendKey(txt_title, str);
}
	
public void enterCompletion(String str) {

	selenium.sendKey(txt_completion, str);
}	

public void selectType(String str) {
	selenium.selectByVisibleText(ddl_task, str);
}

public void selectPriority(String str) {
	selenium.selectByVisibleText(ddl_priority, str);
}


public void enterIndentifier(String str) {
	selenium.sendKey(txt_identifier, str);
}



public void enterTags(String str) {
	
	selenium.sendKey(txt_tags, str);
}


public void enterDescription (String str) {
	
	selenium.sendKey(txt_description, str);
}


public void switchWindow() {
	selenium.getWebElement(btn_companylookup).click();
	selenium.SwitchToWindow(btn_search, btn_submit, link);
	
}


public void SwitchWinCompany() {
	selenium.switchToFrame(frame_name);
	selenium.getWebElement(btn_companylookup).click();
	String parent=selenium.parentWindow();
	String child=selenium.SwitchToWindow();
	//selenium.switchToWindowToClose(str);
	//selenium.sendKeys(btn_search,"Info");
	//selenium.getWebElement(btn_submit).click();
	//selenium.getWebElement(link).click();
	
	RemoteWebDriver driver=selenium.getWebDriver();
	driver.switchTo().window(child);
	driver.findElement(By.xpath("//input[@id='search']")).sendKeys("Info");
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	driver.findElement(By.xpath("//table/tbody/tr[3]/td/table/tbody/tr[2]/td/a")).click();
	//driver.close();
	driver.switchTo().window(parent);
	
}

public void enterDate(String str) {
	
	selenium.sendKeysWithJS(date_deadline, str);
}


public void enterTags() {
	//selenium.defaultContent();
	selenium.switchToFrame(frame_name);
	selenium.sendKey(txt_tags, " This is tag for  TCS");
	
}	


public void  enterDescription() {
	String str="This is description created by DK for TCS company.You are next go live is very soon.Please be ready!!!!!!!!!!!";
	selenium.sendKey(txt_description, str);
}

public void clickSubmit() {

	selenium.getWebElement(btn_save).click();
	
}


public void SwitchWinContact(String str_input) {
	//selenium.switchToFrame(frame_name);
	selenium.getWebElement(btn_contactlookup).click();
	String parent=selenium.parentWindow();
	String child=selenium.SwitchToWindow();
	//selenium.switchToWindowToClose(str);
	//selenium.sendKeys(btn_search,"Info");
	//selenium.getWebElement(btn_submit).click();
	//selenium.getWebElement(link).click();
	
	RemoteWebDriver driver=selenium.getWebDriver();
	driver.switchTo().window(child);
	driver.findElement(By.xpath("//input[@id='search']")).sendKeys("d");
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	List<WebElement> list=driver.findElements(By.xpath("/html/body/table/tbody/tr[3]/td/table/tbody/tr"));
	int size=list.size();
	
	/*for(int i=2;i<=size;i++) {
		
	String str_row=	driver.findElement(By.xpath("//html/body/table/tbody/tr[3]/td/table/tbody/tr["+i+"]/td/a")).getText();	
	str_row=str_row.replaceAll("\\s","");
	str_input=str_input.replaceAll("\\s","");
	System.out.println(str_row+"----"+str_input);
	
	if (str_row.equals(str_input)) {
		driver.findElement(By.xpath("//html/body/table/tbody/tr[3]/td/table/tbody/tr["+i+"]/td/a")).click();
	}
	    break;
	}
	driver.switchTo().window(parent);*/
	
	
	//String str2="Sandeep kale (No Company)";
	str_input=str_input.replaceAll("\\s","");
	
	for (WebElement ele: list) {
		String str1=(ele.getText().trim());
		str1=str1.replaceAll("\\s","");
		
		
		System.out.println(str1+"--"+str_input);	
		
		if (str1.equals(str_input)) 
			 {
			    driver.findElement(By.xpath("//html/body/table/tbody/tr[3]/td/table/tbody/tr[8]/td/a")).click();
			    break;
			}
		 
		}
	
	driver.switchTo().window(parent);
}

/**************************************  Tasks page :Fullsearch form functions ************************************************/

public void clickOnFullSearchForm() {
	
	selenium.switchToFrameToClick(iframe,link_task,link_fullsearchform, frame_name);
	
 }	


public void enterTitleFullSearch(String str) {
	selenium.switchToFrame(frame_name);
	selenium.sendKey(txt_keyword, str);
	
}

public void selectPriorityFullSearch(String str) {
	selenium.selectByVisibleText(ddlsearch_priority, str);
}


public void selectTypeFullSearch(String str) {
	
	selenium.selectByVisibleText(ddlsearch_tasktype, str);
}

public void  clickOnSearchButton() {
	
	selenium.getWebElement(btn_search_task).click();
}


}

