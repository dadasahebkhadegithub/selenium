package pageObjects;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class FullSearchFormPage  extends BasePage{


	 public FullSearchFormPage(TestContext testContext) {
	        super(testContext);

	    }
/****************************************Locators**********************************************/	 
	 String frame_name="mainpanel";
	 private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
	 private Locator link_contact = new Locator(Type.XPATH,"//a[contains(text(),'Contacts')]","contactbutton");
	 private Locator link_Full_Search_Form = new Locator(Type.XPATH,"//div[@id='navmenu']/ul/li[4]/ul/li[3]/a","contactbutton");
	
	 private Locator txt_FirstName = new Locator(Type.XPATH,"//input[@name='cs_first_name']","contactbutton");
	 private Locator txt_surname = new Locator(Type.XPATH,"//input[@name='cs_surname'] ","contactbutton"); 
	 private Locator link_lblcontact = new Locator(Type.XPATH,"//*[@id='vContactsForm']//table//table//tr/td[1]","contactbutton");
	 private Locator btn_search = new Locator(Type.XPATH,"//tr[1]/td[1]/input[@value='Search Contacts']","contactbutton");
	
	 private Locator lbl_searched_user = new Locator(Type.XPATH,"//div[@id='dispAlertMessage']/following::table[9]//tr[1]/td[1]","contactbutton");
	
	 private Locator lbl_search_contact = new Locator(Type.XPATH,"//legend[text()='Search Contact']","contactbutton");

/******************************************Unit Actions ******************************************************/	 
	 
	 public void clickOnFullSearchForm() {
		
		 selenium.switchToFrameToClick(iframe,link_contact,link_Full_Search_Form, frame_name);
			
		 }
	 
	 
	public void  enterFirstName() {
		selenium.switchToFrame(frame_name);
		selenium.sendKey(txt_FirstName, "Dadasaheb");
	}
	 
	 
	public void  enterSurname() {
		selenium.sendKey(txt_surname, "Khade");
	}
	 
	public void clickOnSearch() {
		selenium.click(btn_search);
	}
	
	public void waitPageLoad() {
		selenium.waitForPageLoad();
	}
	
	
	public String  getClickUsername() {
		//selenium.switchToFrame(frame_name);
		return 	selenium.getWebElement(lbl_searched_user).getText().trim();
	
	}
	
	
	/**************************************Getting Value Function *********************************************/
	
	
	
	public String getContatLable() {
		selenium.switchToMainPage();
		 return selenium.switchToFrameToGetText(iframe,link_lblcontact, frame_name);
	}
	
	
	
	public String getSearchContactLable() {
		selenium.switchToFrame(frame_name);
		return selenium.getWebElement(lbl_search_contact).getText().trim();
	}
	
	
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
