package pageObjects;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class HomePage extends BasePage{

	public HomePage(TestContext testContext) {
		super(testContext);
		
	}

	Locator txt_btn =new Locator(Type.XPATH,"//id[]/div/1","xtbutton");
	// why selenium functions are not available here.It is available only in if we write some functions as below .show()
	//selenium
	
	public void show() {
		selenium.click(txt_btn);
	}
	// why selenium functions are not available here.
	//selenium.click(txt_btn);
}
