package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class ContactPage extends BasePage {

	 public ContactPage(TestContext testContext) {
	        super(testContext);

	    }
	 
	 
/****************************************Locators**********************************************/	 
String frame_name="mainpanel";
private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
private Locator link_contact = new Locator(Type.XPATH,"//a[contains(text(),'Contacts')]","contactbutton");
//private Locator link_new_contact= new Locator(Type.XPATH, "//*[@id='navmenu']/ul/li[4]/ul/li[1]/a","new contact form");
private Locator txt_firstname = new Locator(Type.XPATH,"//[@id='first_name']","firstname");
private Locator txt_lastname = new Locator(Type.XPATH,"//[@id='surname']","lastname");
private Locator btn_save = new Locator(Type.XPATH,"//*[@id='contactForm']/table/tbody/tr[1]/td/input[2]","savebutton");
private Locator frameSet = new Locator(Type.XPATH,"//iframe","framset");
private Locator link_new_contact = new Locator(Type.XPATH,"//a[contains(text(),'New Contact')]","contactbutton");
private Locator link_lblcontact = new Locator(Type.XPATH,"//td[contains(text(),'Contacts')]","contactbutton");
private Locator lbl_new_contact = new Locator(Type.XPATH,"//legend[contains(text(),'Contact Information')]","contactnewbutton");

private Locator drp_title = new Locator(Type.XPATH,"//select[@name='title']","contactnewbutton");
private Locator firstname = new Locator(Type.XPATH,"//input[@name='first_name']","contactnewbutton");
private Locator middlename = new Locator(Type.XPATH,"//input[@name='middle_initial']","contactnewbutton");
private Locator surname = new Locator(Type.XPATH,"//input[@name='surname']","contactnewbutton");

private Locator save = new Locator(Type.XPATH,"//*[@id='contactForm']/table/tbody/tr[1]/td/input[2]","contactnewbutton");

private Locator lbl_newCreatedContact = new Locator(Type.XPATH,"//td[@id='tab_vwebresources']/following::tbody[1]/tr[1]/td[1]","contactnewbutton");

private Locator drpdw_suffix =new Locator(Type.XPATH,"//select[@name='suffix']","contactnewbutton"); 

private Locator txt_dept =new Locator(Type.XPATH,"//input[@id='department']","contactnewbutton"); 

private Locator drpdw_category =new Locator(Type.XPATH,"//select[@name='category']","contactnewbutton");

private Locator radio_receive_email_N =new Locator(Type.XPATH,"//input[@name='receive_email' and @value='N']","contactnewbutton");
private Locator radio_receive_sms_Y =new Locator(Type.XPATH,"//input[@name='receive_sms' and @value='Y']","contactnewbutton");

private Locator radio_Allow_call_N =new Locator(Type.XPATH,"//input[@name='allows_call' and @value='N']","contactnewbutton");

private Locator drpdw_network =new Locator(Type.XPATH,"//select[@name='im_netowrk']","contactnewbutton");

private Locator drpdw_source =new Locator(Type.XPATH,"//select[@name='source']","contactnewbutton");

private Locator txt_address_title =new Locator(Type.XPATH,"//input[@name='address_title']","contactnewbutton");

private Locator txt_address =new Locator(Type.XPATH,"//textarea[@name='address']","contactnewbutton");

private Locator txt_country =new Locator(Type.XPATH,"//input[@name='country']","contactnewbutton");

private Locator txt_description =new Locator(Type.XPATH,"//textarea[@name='description']","contactnewbutton");

private Locator drpdw_time_zone =new Locator(Type.XPATH,"//select[@name='time_zone']","contactnewbutton");

private Locator drpdw_country =new Locator(Type.XPATH,"//select[@name='country']","contactnewbutton");

private Locator link_Full_Search_Form = new Locator(Type.XPATH,"//div[@id='navmenu']/ul/li[4]/ul/li[3]/a","contactbutton");



private Locator btn_company_search = new Locator(Type.XPATH,"//*[@id='contactForm']//descendant::table[2]/tbody/tr[8]/td[2]/input[4]","contactbutton");



private Locator txt_company_search = new Locator(Type.XPATH,"//input[@name='client_lookup']","contactbutton");




/*************************************************Contact Page Edit Functionality Locator*******************************************/

private Locator edit_sms =new Locator(Type.XPATH,"//input[@name='receive_sms' and@value='N']","contactnewbutton");

private Locator edit_email =new Locator(Type.XPATH,"//input[@name='receive_email' and@value='N']","contactnewbutton");
private Locator edit_allowcall =new Locator(Type.XPATH,"//input[@name='allows_call' and@value='N']","contactnewbutton");


private Locator edit_lbl =new Locator(Type.XPATH,"//div[@id='leftMenuContainer']/following::table[5]/tbody/tr/td[1]","contactnewbutton");

//***********************************Unit Actions**********************************************************************************
 
public void clickOnContact() {
	selenium.switchToFrame(iframe,link_contact, frame_name);
	
 	}
 

public String getContatLable() {
	// selenium.waitForPageLoad();
	 return selenium.switchToFrameToGetText(iframe,link_lblcontact, frame_name);
}


	public String getTitleOfContactPage() {
	  return selenium.getTitle();
	}


 	public void clickOnNewContact() {
		selenium.switchToFrameToClick(iframe,link_contact,link_new_contact, frame_name);
		
	 }

 	public void clickOnFullSearchForm() {
		selenium.switchToFrameToClick(iframe,link_contact,link_Full_Search_Form, frame_name);
		
	 }
 
  public String getNewContactLabale() {
	  
	  return selenium.switchToFrameToGetText(iframe,lbl_new_contact, frame_name);
  }
  
  public void switchFrame() {
	  selenium.switchToFrame(frame_name);
  }
 
  public void selectTitle(String str) {
	  //selenium.waitForPageLoad();
	   switchFrame();
	  selenium.selectByVisibleText(drp_title, str);  
  }
  
  public void enterFirstName(String firstName) {
	  //switchFrame();
	  selenium.sendKeys(firstname,firstName); 
	  
  }
  
  
  public void enterMiddleName(String middleName) {
	  selenium.sendKey(middlename, middleName); 
  }
  
  public void enterLastName(String lastName) {
	  selenium.sendKeys(surname, lastName); 
  }
  
  public void clickOnSave() {
	  selenium.click(save);
  }
  
  
  public void selectSuffix(String str) {
	  selenium.selectValueFromDropDown(drpdw_suffix, str);
	  
  }
  
  public void switchWinCompany() {
		//selenium.switchToFrame(frame_name);
	   selenium.getWebElement(txt_company_search).clear();
		selenium.getWebElement(btn_company_search).click();
		String parent=selenium.parentWindow();
		String child=selenium.SwitchToWindow();
		//selenium.switchToWindowToClose(str);
		//selenium.sendKeys(btn_search,"Info");
		//selenium.getWebElement(btn_submit).click();
		//selenium.getWebElement(link).click();
		
		RemoteWebDriver driver=selenium.getWebDriver();
		driver.switchTo().window(child);
		driver.findElement(By.xpath("//input[@id='search']")).clear();
		driver.findElement(By.xpath("//input[@id='search']")).sendKeys("Info");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.findElement(By.xpath("//table/tbody/tr[3]/td/table/tbody/tr[2]/td/a")).click();
		//driver.close();
		driver.switchTo().window(parent);
		
	}
  
  public void selectCategory(String str) {
	  selenium.switchToFrame(frame_name);
	  selenium.isOptionPresentUnderDropDown(drpdw_category, str);
  }
  
  public void selectCategoryByParameters(String str) {
	  //selenium.switchToFrame(frame_name);
	  selenium.isOptionPresentUnderDropDown(drpdw_category, str);
  }
  
  public String getNewCreatedContacName() {
	 return  selenium.getText(lbl_newCreatedContact);
  }
  
  public void selectReceviedEmail() {
	  selenium.click(radio_receive_email_N);
  }
  
  public void selectReceviedSms() {
	  selenium.click(radio_receive_sms_Y);
  }
   
  public void selectAllowCalls() {
	  
	  selenium.click(radio_Allow_call_N);
  }
  
  public void  selectMessagenerNetwork(String str) {
	  selenium.selectValueFromDropDown(drpdw_network, str);
  }
  
  public void selectSource(String str) {
	selenium.selectValueFromDropDown(drpdw_source, str);
  }
    
  public void selectDate(String str) {
	  selenium.selectDateFromCalendar(str);
  }
  
  public void enterAddressTitle(String str) {
	  selenium.sendKey(txt_address_title, str); 
  }
  
  public void enterAddress(String str) {
	  selenium.sendKey(txt_address, str); 
  }
  
  public void scroll() {
	  selenium.scrollToElement(txt_address);
  }
  
  public void scrollUp() {
	  selenium.scrollUpToTheTopOfPage();
  }
    public void enterCountry(String str) {
	  selenium.sendKey(txt_country, str); 
  }
 
    public void selectTimeZone() {
  	  selenium.selectValueFromDropDown(drpdw_time_zone, "IST - India Standard Time");
  	  
    }   
   
    
    public void selectCountry() {
    	  selenium.selectValueFromDropDown(drpdw_country, "India");
    	  
      }   
    
    
    public void enterDepartment() {
    	//selenium.switchToFrame(frame_name);
    	selenium.sendKey(txt_dept, "Software");
    }
    
    
 /***********************Contact page Edit functionality ***************************/    
    
   
    
    public void editAllowCalls() {
  	  
  	  selenium.click(edit_allowcall);
    }
    
    public void editSMS() {
    	  
    	  selenium.click(edit_sms);
      }
   
    public void editEmail() {
  	  
  	  selenium.click(edit_email);
    }
    
    
    public String getEditedContacName() {
   	 return  selenium.getText(edit_lbl);
     }
}

