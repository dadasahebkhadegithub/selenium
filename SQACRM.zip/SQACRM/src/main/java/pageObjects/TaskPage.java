package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class TaskPage extends BasePage{

	
	public TaskPage(TestContext testContext) {
        super(testContext);

 
	}
	
	
/***************************************Locators******************************************************/	
	String frame_name="mainpanel";
	private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
	private Locator link_task = new Locator(Type.XPATH,"//a[contains(text(),'Tasks')]","contactbutton");
	private Locator link_full_search_form= new Locator(Type.XPATH, "//div[@id='navmenu']/ul/li[6]/ul/li[2]/a","new contact form");	
	private Locator txt_cs_completion = new Locator(Type.XPATH,"//input[@name='cs_completion']","contactbutton");
	private Locator drpdw_cs_status = new Locator(Type.XPATH,"//select[@name='cs_status']","contactbutton");
	private Locator txt_cs_company = new Locator(Type.XPATH,"//input[@name='cs_company_name']","contactbutton");
	private Locator btn_submit = new Locator(Type.XPATH,"//input[@value='Search' and @name='cs_submit']","contactbutton");
	
	private Locator txt_search_title = new Locator(Type.XPATH,"//input[@name='cs_search_title']","contactbutton");
	
	private Locator chk_save_search = new Locator(Type.XPATH,"//input[@name='cs_save_search']","contactbutton");
	
	
	private Locator grid_result = new Locator(Type.XPATH,"//form[@name='TASKSEARCH']//table[2]/tbody/tr[3]/td[1]","contactbutton");
	
	private Locator search_tbl_heading1 = new Locator(Type.XPATH,"//form[@name='TASKSEARCH']/descendant::table[1]/tbody/tr[1]/td[1]","contactbutton");
	
	//div[@id='extendedSearchLayer']/descendant::table[3]/tbody/tr[8]/td[2]	
	
	private Locator delete_save_lbl = new Locator(Type.XPATH,"//div[@id='extendedSearchLayer']/descendant::table[3]/tbody/tr[8]/td[2]","contactbutton");
	
	
	
/**************************************Unit Action *****************************************************/
	
	public void clickOnTask() {
		selenium.switchToFrame(iframe,link_task, frame_name);
		//selenium.switchToFrame(frame_name);
		//String str=	selenium.getWebElement(search_tbl_heading1).getText();
		//System.out.println(str);
	
		
	 	}
	
	public void enterCompletion() {
		
		selenium.switchToFrame(frame_name);
		selenium.sendKey(txt_cs_completion, "75");
	}
	
	public  void selectStatus() {
		
		selenium.selectByVisibleText(drpdw_cs_status, "Open");
	}

	public void enterCompany() {
		selenium.sendKey(txt_cs_company, "Infosys");
	}
	
	
	public void clickSubmit() {
		selenium.getWebElement(btn_submit).click();
	}
	
	
	public String  searchResultGrid() {
		
		return selenium.getWebElement(grid_result).getText().trim();
		
	}
	
	
	public void lbltext() {
		selenium.switchToFrame(frame_name);
		String str=selenium.getWebElement(search_tbl_heading1).getText();
		System.out.println(str);
	}
	
	
	
	public void clickOnSaveSearch() {
		//selenium.switchToFrame(frame_name);
		selenium.getWebElement(chk_save_search).click();
		//selenium.sendKey(txt_search_title,"Dk Search");
		boolean flag=selenium.waitForElementToBeDisplayed(txt_search_title);
		if (flag)
		{
			selenium.sendKey(txt_search_title,"Dada task Search");
		}
		
	}

	
public boolean  deleSavelbl() {
	
	boolean flag=selenium.getWebElement(delete_save_lbl).isDisplayed();
	
	System.out.println(flag);
	return flag;
	
	
		/*List<WebElement> list =selenium.getWebElements(delete_save_lbl);
		String str="";
		for (WebElement ele:list) {
		str=ele.getText().trim();
		}
		
		//String strArray[]=str.split(" ");
		
		for (int i =0 ;i<str.length();i++) {
			
			List<String> list1=new ArrayList<String>();
			if (!(str==" ")){
				
				list1.add(str);
			}
			
			
			System.out.println(list1);
		}*/
		
		
		
	}
	
	

}	
	
	
	

