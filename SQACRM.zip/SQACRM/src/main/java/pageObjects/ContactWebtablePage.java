package pageObjects;

import java.util.List;

import org.openqa.selenium.WebElement;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;

public class ContactWebtablePage extends  BasePage {

	 public ContactWebtablePage(TestContext testContext) {
	        super(testContext);

	    }
	
	
/********************************Locators**************************************************************************/
	 String frame_name="mainpanel";
private Locator tble_col_heading_contant = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr[3]","contactbutton");

private Locator rowcount = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr[3]/following-sibling::tr","contactbutton");

private Locator columncount = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr[3]/child::td","contactbutton");

private Locator lbl_newCreatedContact = new Locator(Type.XPATH,"//table/descendant::table[4]//tbody/tr/td","contactnewbutton");

public String   getColumnHeaders() {
	selenium.switchToFrame(frame_name);
	List<WebElement> webelement = selenium.getWebElements(tble_col_heading_contant);
	String str="";
	for(WebElement ele: webelement) {
		str=ele.getText().trim();
	}
	return str;
}



public int getRowCount() {
	selenium.switchToFrame(frame_name);
	List<WebElement> webelement = selenium.getWebElements(rowcount);
	int size=webelement.size();
	System.out.println(size);
	int count=0;
	for(WebElement ele: webelement) {
		if (!(ele.getText().isEmpty())) {
			count++;
		}
	}
	System.out.println(count);
	return count;
}


	public int   getColumnCount() {
	selenium.switchToFrame(frame_name);
	List<WebElement> webelement = selenium.getWebElements(columncount);
	int size=webelement.size();
	return size;
	}


	public void getRowValue(int row ) {
	
		int rowsize=getRowCount();
		for (int i=4;i<=rowsize;i++) {
			if (row==i) {
				 Locator rowvalue = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr[" +row+ "]/td[2]","contactbutton");
				//selenium.switchToFrame(frame_name);
				String str= selenium.getWebElement(rowvalue).getText();
				selenium.getWebElement(rowvalue).click();
				System.out.println("Row no "+i+" value "+ str+ " is selected ");
			}
		}
	
	}

	public void getRowValue(String name ) {
		
		int rowsize=getRowCount();
		for (int i=4;i<=rowsize;i++) {
			
				 Locator rowvalue = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr["+i+"]/td[2]/a","contactbutton");
				//selenium.switchToFrame(frame_name);
				String str= selenium.getWebElement(rowvalue).getText();
				if(str.contains(name)) {
				//selenium.JSClick(rowvalue);
					selenium.getWebElement(rowvalue).click();
				System.out.println("Expected name: "+ name+ " is selected ");
				break;
				}
		}
	
	}
	
	public void clickOnRowEditlink() {
		selenium.switchToFrame(frame_name);
		List<WebElement> webelement = selenium.getWebElements(rowcount);
		int size=webelement.size();
		if(size>0) {
			Locator rowvalue = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr[5]/td[8]/a/i[@title='Edit']","contactbutton");
			selenium.getWebElement(rowvalue).click();
		}
		selenium.defaultContent();	
	}

	
public String getRowValues (String name ) {
		
		selenium.switchToFrame(frame_name);
		String str="";
		for (int i=4;i<=50;i++) {
			
				 Locator rowvalue = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr["+i+"]/td[2]/a","contactbutton");
				 str= selenium.getWebElement(rowvalue).getText();
				 break;
 
		}
		return str;
	}


public String getRowValueClick (String name ) {
	
	//selenium.switchToFrame(frame_name);
	String str="";
	for (int i=4;i<=50;i++) {
		
			 Locator rowvalue = new Locator(Type.XPATH,"//*[@id='vContactsForm']/table/tbody/tr["+i+"]/td[2]/a","contactbutton");
			 str= selenium.getWebElement(rowvalue).getText();
			 selenium.getWebElement(rowvalue).click();
			 break;

	}
	//selenium.defaultContent();
	return str;
}


	
}
