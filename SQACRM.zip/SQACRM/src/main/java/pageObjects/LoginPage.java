package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import basePage.BasePage;
import dataHandlers.TestContext;
import utils.Locator;
import utils.Locator.Type;
public class LoginPage extends BasePage {

	  public LoginPage(TestContext testContext) {
	        super(testContext);

	  }
	  String frame_name="mainpanel";
	private Locator iframe = new Locator(Type.XPATH,"//frame","contactbutton");
	private Locator lbl_username = new Locator(Type.XPATH, "//table[1]/tbody/tr[1]//tbody[1]/tr/td[contains(text(),'Dadasaheb Khade')]", "text field username");
	private Locator txt_username = new Locator(Type.XPATH, "//form[@id='loginForm']/div/input[1]", "text field username");
	private Locator txt_password = new Locator(Type.XPATH, "//form[@id='loginForm']/div/input[2]", "text Field password");
	private Locator btn_login = new Locator(Type.XPATH, "//input[contains(@type,'submit')]", "button login");
	//
	private Locator btn_logout = new Locator(Type.XPATH, "//a[contains(text(),'Logout')]", "button login");

	
	  public void loginIntoTheApp(String uname,String pwd) {
		  selenium.sendKey(txt_username, uname);
		  selenium.sendKey(txt_password, pwd);
		  selenium.clickWithJS(btn_login);
		  
	  }
	  
	  public String  getLoggedInUserName() {
		 /* String str= selenium.switchToFrameToGetText(iframe,lbl_username, frame_name);
		  return str;*/
		 return selenium.switchToFrameToGetText(iframe,lbl_username, frame_name);
	  }
	  
	  
	  
	  public String getTitleOfLandinPage() {
		 return  selenium.getTitle();
	  }
	  
	  public void logOut() {
		  selenium.switchToFrame(iframe,btn_logout,frame_name);
		  
	  }
}
