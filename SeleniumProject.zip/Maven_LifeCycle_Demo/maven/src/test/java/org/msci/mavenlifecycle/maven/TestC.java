package org.msci.mavenlifecycle.maven;

public class TestC {

}
