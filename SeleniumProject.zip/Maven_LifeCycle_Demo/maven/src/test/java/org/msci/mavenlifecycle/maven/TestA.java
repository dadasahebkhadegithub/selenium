package org.msci.mavenlifecycle.maven;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

import org.testng.annotations.Test;

public class TestA {

	@Test
	public void add() throws URISyntaxException {
		System.out.println("Inside add methode");
		URL res=getClass().getClassLoader().getResource("TestData/NewTask.xlsx");
		File file = Paths.get(res.toURI()).toFile();
		String absolutePath = file.getAbsolutePath();
		System.out.println(absolutePath);
	}
	
	@Test
	public void sub() {
		System.out.println("Inside sub methode");
	}
	
	@Test
	public void mul() {
		System.out.println("Inside mul methode");
	}
	
	
	@Test
	public void div() {
		System.out.println("Inside div methode");
	}
}
