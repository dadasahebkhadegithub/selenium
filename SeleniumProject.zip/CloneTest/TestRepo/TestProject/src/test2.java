
public class test2 {

	 public void add() {
		  
	  }
	  public void delete (){
		  
	  }
}
