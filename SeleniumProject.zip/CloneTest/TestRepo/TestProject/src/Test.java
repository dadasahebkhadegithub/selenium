
public class Test {
  public void add() {
	  
  }
  public void delete (){
	  
  }
}
