package com.qa.CRM.CRM;

public class TasksPage {

}
