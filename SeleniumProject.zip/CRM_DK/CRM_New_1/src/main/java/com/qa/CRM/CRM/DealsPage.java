package com.qa.CRM.CRM;

public class DealsPage {

}
