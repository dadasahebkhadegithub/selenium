package com.qa.qtpselenium.facebook.com.util;

public class FBConstants {

	
	//PATH
	public static final String CHROME_DRIVER_EXE="E:\\SeleniumProject\\ChromeDriver\\chromedriver_win32\\chromedriver.exe";
	public static final String REPORTS_PATH = "E:\\reports\\";
	
	
	//LOCATORS
	public static final String LOGIN_USERNAME = "//*[@id='email']";
	public static final String LOGIN_PASSWORD = "//*[@id='pass']";


	//URL
	public static final String HOME_PAGE_URL = "http://www.facebook.com";


	
	//public static final String REPORTS_PATH = "E:\\reports\\";
	
}
