package com.qa.qtpselenium.facebook.com.pages.session;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.qtpselenium.facebook.com.base.Basepage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LandingPage extends Basepage{
	//WebDriver driver;
	
	public LandingPage(WebDriver driver,ExtentTest test) {
		super(driver,test);
	}
	
	@FindBy(xpath="//*[@id='pagelet_welcome_box']/ul/li[1]/div/a")
	public WebElement profilelink;
	
	
	public ProfilePage gotoProfilePage() {
		test.log(LogStatus.INFO,"Going to profile page");
		profilelink.click();
		ProfilePage profilepage=new ProfilePage(driver,test);
		PageFactory.initElements(driver,profilepage);
		return profilepage;
	}
	
}
