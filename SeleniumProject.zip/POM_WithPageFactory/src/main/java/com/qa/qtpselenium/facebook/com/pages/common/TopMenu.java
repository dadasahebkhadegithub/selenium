package com.qa.qtpselenium.facebook.com.pages.common;

import org.openqa.selenium.WebDriver;

public class TopMenu {

	public WebDriver driver;
	
	public TopMenu (WebDriver driver) {
		this.driver=driver;
	}
	
	public void logout () {
		
	}
	
	public void gotoSetting () {
		
	}
	
	public void search() {
		
	}
}
