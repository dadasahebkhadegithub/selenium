package com.qa.qtpselenium.facebook.com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.qtpselenium.facebook.com.base.Basepage;
import com.qa.qtpselenium.facebook.com.pages.session.LandingPage;
import com.qa.qtpselenium.facebook.com.util.FBConstants;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginPage extends Basepage{
	
	//"//*[@id='email']";
	@FindBy(xpath=FBConstants.LOGIN_USERNAME)
	public WebElement email;
	
	//"//*[@id='pass']"
	@FindBy(xpath=FBConstants.LOGIN_PASSWORD)
	public WebElement password;
	
	
	
	public LoginPage(WebDriver driver,ExtentTest test) {
		super (driver,test);
		
	}
	
	 public Object doLogin(String usName,String pWord) {
		 test.log(LogStatus.INFO,"Logging with" +usName);
		 email.sendKeys(usName);
		 password.sendKeys(pWord);
		 password.sendKeys(Keys.ENTER);
		 //we have to write the logic for validation whether login is successful or not 
		 boolean loginSuccess=true;
		 if (loginSuccess) {
			 test.log(LogStatus.INFO,"Login Success");
			 LandingPage landingpage=new LandingPage(driver,test);
			 PageFactory.initElements(driver,landingpage ); 
			 return landingpage;
		 }
		 
		 else {
			 test.log(LogStatus.INFO,"Login not Success");
			 LoginPage loginpage=new LoginPage(driver,test);
			 PageFactory.initElements(driver, loginpage);
			 return loginpage;
		 }
	 }
	 
	 
}
