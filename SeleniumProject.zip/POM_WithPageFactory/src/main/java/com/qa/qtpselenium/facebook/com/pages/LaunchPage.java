package com.qa.qtpselenium.facebook.com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.qa.qtpselenium.facebook.com.base.Basepage;
import com.qa.qtpselenium.facebook.com.util.FBConstants;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LaunchPage extends Basepage {
	//public WebDriver driver;
	
	public LaunchPage(WebDriver driver,ExtentTest test) {
		super(driver,test);
		
		//System.out.println("Dadasaheb Khade");
		//driver.get("http://google.com");
			
	}

	

	public LoginPage gotoLoginPage() {
		test.log(LogStatus.INFO, "Opening the URL--> www.facebook.com");
		
		driver.get("http://www.facebook.com");
		
		test.log(LogStatus.INFO, "www.facebook.com URL opened");
		
		LoginPage loginpage=new LoginPage(driver,test);
		PageFactory.initElements(driver,loginpage);
		return loginpage;
	}

	
	
}
