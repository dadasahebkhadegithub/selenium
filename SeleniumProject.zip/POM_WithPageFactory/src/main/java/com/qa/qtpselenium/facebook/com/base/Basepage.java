package com.qa.qtpselenium.facebook.com.base;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.qa.qtpselenium.facebook.com.pages.common.TopMenu;
import com.qa.qtpselenium.facebook.com.util.FBConstants;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Basepage {

	
	public WebDriver driver;
	public TopMenu menu;
	public ExtentTest test;
	
	
	public Basepage(WebDriver driver,ExtentTest test) {
		this.driver=driver;
		this.test=test;
		menu=PageFactory.initElements(driver, TopMenu.class);
	}
	
	
	public String  verifyTitle(String expTitle) {
		test.log(LogStatus.INFO, "Verifying the title" + expTitle);
		
		return "";
	}
	
	public String verifyText(String locator,String expText) {
		return "";
		
	}
	
	public  boolean isElementPresent(String locator) {
		return 	false;
	}
	
	
	public void takescreenshot() {
		Date d=new Date();
		String screenshotFile=d.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=FBConstants.REPORTS_PATH+"screenshots//"+screenshotFile;
		// store screenshot in that file
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.INFO,test.addScreenCapture(filePath));
	}
	
	
	public TopMenu getMenu() {
		return menu;
	}
	
	
	
	
	
	
}
