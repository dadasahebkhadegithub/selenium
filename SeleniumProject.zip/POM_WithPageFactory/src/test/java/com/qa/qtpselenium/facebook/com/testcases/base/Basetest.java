package com.qa.qtpselenium.facebook.com.testcases.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.qa.qtpselenium.facebook.com.util.ExtentManager;
import com.qa.qtpselenium.facebook.com.util.FBConstants;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Basetest {
	public ExtentReports extent=ExtentManager.getInstance();
	public ExtentTest test;
	
	
	
	public WebDriver driver;
	public void  init(String bType) {
		test.log(LogStatus.INFO,"Opening browser"+bType);
		if (bType.equals("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "E:\\SeleniumProject\\FirefoxDriver\\geckodriver-v0.21.0-arm7hf\\geckodriver.exe");
			driver=new FirefoxDriver();
			}
		else if(bType.equals("Chrome")) {
		System.setProperty("webdriver.chrome.driver", FBConstants.CHROME_DRIVER_EXE);
		driver=new ChromeDriver();	
			}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		test.log(LogStatus.INFO,"Opened browser sucessfully"+bType);
		
		
		
	}
}
