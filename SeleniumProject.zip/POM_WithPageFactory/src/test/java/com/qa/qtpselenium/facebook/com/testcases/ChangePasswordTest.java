package com.qa.qtpselenium.facebook.com.testcases;

public class ChangePasswordTest {

}
