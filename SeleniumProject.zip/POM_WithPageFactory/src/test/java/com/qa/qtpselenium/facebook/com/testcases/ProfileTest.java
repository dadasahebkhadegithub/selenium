package com.qa.qtpselenium.facebook.com.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.qa.qtpselenium.facebook.com.base.Basepage;
import com.qa.qtpselenium.facebook.com.pages.LaunchPage;
import com.qa.qtpselenium.facebook.com.pages.LoginPage;
import com.qa.qtpselenium.facebook.com.pages.session.LandingPage;
import com.qa.qtpselenium.facebook.com.pages.session.ProfilePage;
import com.qa.qtpselenium.facebook.com.testcases.base.Basetest;
import com.relevantcodes.extentreports.LogStatus;

public class ProfileTest extends Basetest {
	@Test
	public void testProfile() {
		test=extent.startTest("Profile Test");
		test.log(LogStatus.INFO,"Starting profile test");
		
		init("Chrome");
		
		LaunchPage launchpage=new LaunchPage(driver,test);
		PageFactory.initElements(driver,launchpage);
		
		LoginPage loginpage=launchpage.gotoLoginPage();
		loginpage.verifyTitle("Facebook login");
		Object page=loginpage.doLogin("dada.khade@gmail.com", "dadakhade");
		if(page instanceof LoginPage)
			Assert.fail("Login failed");
		else if (page instanceof LandingPage)
			System.out.println("Logged in sucessfully");
		
		LandingPage	landingpage=(LandingPage)page;
		//landingpage.getMenu().gotoSetting();
		ProfilePage profilepage =landingpage.gotoProfilePage();
		profilepage.verifyProfile();
		profilepage.takescreenshot();
		test.log(LogStatus.INFO,"Test Passed");
		//profilepage.getMenu().logout();
		
	}
	
	@AfterMethod
	public void quit() {
		if(extent!=null) {
			extent.endTest(test);
			extent.flush();
		}
			
	}
}

