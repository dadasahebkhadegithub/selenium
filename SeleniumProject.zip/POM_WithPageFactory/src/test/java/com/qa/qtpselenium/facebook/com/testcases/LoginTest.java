package com.qa.qtpselenium.facebook.com.testcases;


import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.qa.qtpselenium.facebook.com.base.Basepage;
import com.qa.qtpselenium.facebook.com.pages.LaunchPage;
import com.qa.qtpselenium.facebook.com.pages.LoginPage;
import com.qa.qtpselenium.facebook.com.testcases.base.Basetest;
import com.qa.qtpselenium.facebook.com.util.ExtentManager;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginTest extends Basetest {

	@Test
		
	public void doLogin() {
		
		
		test= extent.startTest("Login test");
		test.log(LogStatus.INFO, "Starting login test");
		test.log(LogStatus.INFO, "Opening Browser");
		
		init("Firefox");
		
		LaunchPage launchpage= new LaunchPage(driver,test);
		PageFactory.initElements(driver,LaunchPage.class);
		
		LoginPage loginpage=launchpage.gotoLoginPage();
		
		test.log(LogStatus.INFO,"Logging in");
		
		loginpage.doLogin("dada.khade@gmail.com", "dadakhade");
		
		test.log(LogStatus.PASS,"Login Test Passed");
		
		//extent.endTest(test);
		//extent.flush();
	}
	
	@AfterMethod
	public void quit() {
		if(extent!=null) {
			extent.endTest(test);
			extent.flush();
		}
			
	}
}
